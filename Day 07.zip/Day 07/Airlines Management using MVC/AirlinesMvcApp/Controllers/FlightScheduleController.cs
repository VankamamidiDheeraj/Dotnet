﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AirlinesMvcApp.Controllers
{
    public class FlightScheduleController : Controller
    {
        // GET: FlightScheduleController
        public ActionResult Index()
        {
            return View();
        }

        // GET: FlightScheduleController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: FlightScheduleController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: FlightScheduleController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: FlightScheduleController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: FlightScheduleController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: FlightScheduleController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: FlightScheduleController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
