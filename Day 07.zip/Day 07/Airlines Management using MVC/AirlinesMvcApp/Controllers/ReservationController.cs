﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EFAirlinesLibrary.Models;
using EFAirlinesLibrary.Repos;
using System.Threading.Tasks;
namespace AirlinesMvcApp.Controllers
{
    public class ReservationController : Controller {
        IReservationRepository reservationRepo;
        IPassengerRepository passengerRepo;
        public ReservationController(IReservationRepository reservationRepository, IPassengerRepository passengerRepository) {
            reservationRepo = reservationRepository;   
            passengerRepo = passengerRepository;
        }
        public async Task<ActionResult> Index() {
            List<Reservation> reservations = await reservationRepo.GetAllReservationsAsync();
            return View(reservations);
        }
        public async Task<ActionResult> Details(string pnr) {
            Reservation reservation = await reservationRepo.GetReservationAsync(pnr);
            return View();
        }
        public ActionResult Create() {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Reservation reservation) {
            try {
                await reservationRepo.InsertReservationAsync(reservation);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }

        // GET: ReservationController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: ReservationController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ReservationController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: ReservationController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
        static int passCount;
        public async Task<ActionResult> Passengers(string pnr) {
            List<Passenger> passengers;
            try {
                passengers = await passengerRepo.GetPassengersByPNRAsync(pnr);
            }
            catch {
                passengers = new List<Passenger>();
            }
            TempData["PNR"] = pnr;
            passCount = passengers.Count;
            return View(passengers);
        }
        public ActionResult CreatePassenger(string pnr) {
            Passenger passenger = new Passenger();
            passenger.PNR = pnr;
            passCount++;
            passenger.PassengerNo = passCount;
            return View(passenger);
        }
        [HttpPost]
        public async Task<ActionResult> CreatePassenger(Passenger passenger) {
            await passengerRepo.InsertPassengerAsync(passenger);
            return RedirectToAction("Passengers", new { pnr = passenger.PNR });
        }
        public async Task<ActionResult> PassengerDetails(string pnr, int passNo) {
            Passenger passenger = await passengerRepo.GetPassengerAsync(pnr, passNo);
            return View(passenger);
        }
    }
}
