﻿using EFAirlinesLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFAirlinesLibrary.Repos
{
    public interface IFlightScheduleRepository
    {
        Task InsertScheduleAsync(FlightSchedule schedule);
        Task UpdateScheduleAsync(string flightNo, DateTime flightDate, FlightSchedule schedule);
        Task DeleteScheduleAsync(string flightNo, DateTime flightDate);
        Task<List<FlightSchedule>> GetAllSchedulesAsync();
        Task<FlightSchedule> GetScheduleAsync(string flightNo, DateTime flightDate);
        Task<List<FlightSchedule>> GetSchedulesByFlightAsync(string flightNo);
        Task<List<FlightSchedule>> GetSchedulesByDateAsync(DateTime flightDate);
    }
}
