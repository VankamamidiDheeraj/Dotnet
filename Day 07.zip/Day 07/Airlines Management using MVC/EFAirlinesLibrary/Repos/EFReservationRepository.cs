﻿using EFAirlinesLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFAirlinesLibrary.Repos
{
    public class EFReservationRepository : IReservationRepository {
        ZelisAirlinesDBContext ctx = new ZelisAirlinesDBContext();
        public async Task DeleteReservationAsync(string pnr) {
            Reservation res2del = await GetReservationAsync(pnr);
            try {
                ctx.Reservations.Remove(res2del);
                await ctx.SaveChangesAsync();
            }
            catch (Exception ex) {
                throw new AirlinesException(ex.Message);
            }
        }
        public async Task<List<Reservation>> GetAllReservationsAsync() {
            List<Reservation> reservations = await ctx.Reservations.ToListAsync();
            return reservations;
        }
        public async Task<Reservation> GetReservationAsync(string pnr) {
            try {
                Reservation reservation = await (from r in ctx.Reservations where r.PNR == pnr select r).FirstAsync();
                return reservation;
            }
            catch {
                throw new AirlinesException("PNR not found!");
            }
        }
        public async Task<List<Reservation>> GetReservationsByDateAsync(DateTime resDate) {
            List<Reservation> reservations = await ctx.Reservations.Where(r => r.ReservationDate == resDate).ToListAsync();
            if (reservations.Count == 0) {
                throw new AirlinesException("No reservations found for the given date!");
            }
            else {
               return reservations;
            }
        }
        public async Task<List<Reservation>> GetReservationsByScheduleAsync(string flightNo, DateTime flightDate) {
            List<Reservation> reservations = await (from r in ctx.Reservations where r.FlightNo == flightNo && r.FlightDate == flightDate select r).ToListAsync();
            if (reservations.Count == 0) {
                throw new AirlinesException("No reservations found for this schedule");
            }
            else {
                return reservations;
            }
        }
        public async Task InsertReservationAsync(Reservation reservation) {
            try {
                await ctx.Reservations.AddAsync(reservation);
                await ctx.SaveChangesAsync();
            }
            catch (Exception ex) {
                throw new AirlinesException(ex.Message);
            }
        }
        public async Task UpdateReservationAsync(string pnr, Reservation reservation) {
            Reservation reservation2edit = await GetReservationAsync(pnr);
            try {
                reservation2edit.FlightNo = reservation.FlightNo;
                reservation2edit.FlightDate = reservation.FlightDate;
                reservation2edit.ReservationDate = reservation.ReservationDate;
                await ctx.SaveChangesAsync();
            }
            catch (Exception ex) {
                throw new AirlinesException(ex.Message);
            }
        }
    }
}
