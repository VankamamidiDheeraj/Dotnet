﻿using EFAirlinesLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFAirlinesLibrary.Repos
{
    public interface IFlightRepository
    {
        Task InsertFlightAsync(Flight flight);
        Task UpdateFlightAsync(string flightNo, Flight flight);
        Task DeleteFlightAsync(string flightNo);
        Task<List<Flight>> GetAllFlightsAsync();
        Task<Flight> GetFlightAsync(string flightNo);
    }
}
