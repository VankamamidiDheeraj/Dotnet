﻿using EFAirlinesLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFAirlinesLibrary.Repos
{
    public class EFFlightScheduleRepository : IFlightScheduleRepository {
        ZelisAirlinesDBContext ctx = new ZelisAirlinesDBContext();
        public async Task DeleteScheduleAsync(string flightNo, DateTime flightDate) {
            FlightSchedule schedule2del = await GetScheduleAsync(flightNo, flightDate);
            try {
                ctx.FlightSchedules.Remove(schedule2del);
                await ctx.SaveChangesAsync();
            }
            catch (Exception ex) {
                throw new AirlinesException(ex.Message);
            }
        }
        public async Task<List<FlightSchedule>> GetAllSchedulesAsync() {
            List<FlightSchedule> schedules = await ctx.FlightSchedules.ToListAsync();
            return schedules;
        }
        public async Task<FlightSchedule> GetScheduleAsync(string flightNo, DateTime flightDate) {
            try {
                FlightSchedule schedule = await ctx.FlightSchedules.Where(s => s.FlightNo == flightNo && s.FlightDate == flightDate).FirstAsync();
                return schedule;
            }
            catch {
                throw new AirlinesException("Flight no or date not found!");
            }
        }
        public async Task<List<FlightSchedule>> GetSchedulesByDateAsync(DateTime flightDate) {
            List<FlightSchedule> schedules = await ctx.FlightSchedules.Where(s => s.FlightDate == flightDate).ToListAsync();
            if (schedules.Count == 0) {
                throw new AirlinesException("No schedules found for the given date!");
            }
            else {
               return schedules;
            }
        }
        public async Task<List<FlightSchedule>> GetSchedulesByFlightAsync(string flightNo) {
            List<FlightSchedule> schedules = await ctx.FlightSchedules.Where(s => s.FlightNo == flightNo).ToListAsync();
            if (schedules.Count == 0) {
                throw new AirlinesException("No schedules found for the given flight!");
            }
            else {
               return schedules;
            }
        }
        public async Task InsertScheduleAsync(FlightSchedule schedule) {
            try {
                await ctx.FlightSchedules.AddAsync(schedule);
                await ctx.SaveChangesAsync();
            }
            catch (Exception ex) {
                throw new AirlinesException(ex.Message);
            }
        }
        public async Task UpdateScheduleAsync(string flightNo, DateTime flightDate, FlightSchedule schedule) {
            FlightSchedule schedule2edit = await GetScheduleAsync(flightNo, flightDate);
            try {
                schedule2edit.DepartTime = schedule.DepartTime;
                schedule2edit.ArriveTime = schedule.ArriveTime;
                await ctx.SaveChangesAsync();
            }
            catch (Exception ex) {
                throw new AirlinesException(ex.Message);
            }
        }
    }
}
