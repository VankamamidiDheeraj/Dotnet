﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFAirlinesLibrary.Models {
    public class GenderValidation {
        public static ValidationResult IsValidGender(string gender) {
            if (gender == "M" || gender == "F" || gender == "O")
                return ValidationResult.Success;
            else
                return new ValidationResult("Invalid gender");
        }
    }
    [Table("Passenger")]
    [PrimaryKey("PNR", "PassengerNo")]
    public class Passenger {
        [Column(TypeName = "CHAR(6)")]
        [ForeignKey("Reservation")]
        public string PNR { get; set; }
        public int PassengerNo { get; set; }
        [Column(TypeName = "VARCHAR(30)")]
        public string PassengerName { get; set; }
        [Column(TypeName = "CHAR(1)")]
        [CustomValidation(typeof(GenderValidation), "IsValidGender")]
        public string Gender { get; set; }
        public int Age { get; set; }

        public virtual Reservation Reservation { get; set; }
    }
}
