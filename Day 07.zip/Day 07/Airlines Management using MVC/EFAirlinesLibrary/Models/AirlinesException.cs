﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFAirlinesLibrary.Models
{
    public class AirlinesException : Exception
    {
        public AirlinesException(string errMsg) : base(errMsg)
        {
            
        }
    }
}
