﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EFEmployeeLibray.Models;
using EFEmployeeLibray.Repos;
namespace EmployeeMvcApp.Controllers {
    public class EmployeeController : Controller {
        IEmployeeRepository empRepo;
        public EmployeeController(IEmployeeRepository repository) {
            empRepo = repository;
        }
        public ActionResult Index() {
            List<Employee> employees = empRepo.GetAllEmployees();
            return View(employees);
        }
        public ActionResult Details(int id) {
            Employee employee = empRepo.GetEmployee(id);
            return View(employee);
        }
        public ActionResult Create() {
            Employee emp = new Employee();
            return View(emp);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Employee emp) {
            try {
                empRepo.InsertEmployee(emp);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        public ActionResult Edit(int id) {
            Employee employee = empRepo.GetEmployee(id);
            return View(employee);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Employee emp) {
            try {
                empRepo.UpdateEmployee(id, emp);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        public ActionResult Delete(int id) {
            Employee employee = empRepo.GetEmployee(id);
            return View(employee);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection) {
            try {
                empRepo.DeleteEmployee(id);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
    }
}
