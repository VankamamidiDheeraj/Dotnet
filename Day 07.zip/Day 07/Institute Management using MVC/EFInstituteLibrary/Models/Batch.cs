﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFInstituteLibrary.Models
{
    [Table("Batch")]
    public class Batch
    {
        [Key]
        [Column(TypeName = "CHAR(5)")]
        public string BatchCode { get; set; }
        [Column(TypeName = "CHAR(4)")]
        [ForeignKey("Course")]
        public string CourseCode { get; set; }
        [Column(TypeName = "DATETIME")]
        public DateTime StartDate { get; set; }
        [Column(TypeName = "DATETIME")]
        public DateTime EndDate { get; set; }

        public virtual Course Course { get; set; }
        public virtual ICollection<Student> Students { get; set; } = new List<Student>();
    }
}
