﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFInstituteLibrary.Models
{
    [Table("Course")]
    public class Course
    {
        [Key]
        [Column(TypeName = "CHAR(4)")]
        public string CourseCode { get; set; }
        [Column(TypeName = "VARCHAR(20)")]
        [Required]
        public string CourseTitle { get; set; }
        public int CourseDuration { get; set; }
        [Column(TypeName = "MONEY")]
        public decimal CourseFee { get; set; }

        public virtual ICollection<Batch> Batches { get; set; } = new List<Batch>();
    }
}
