﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EFInstituteLibrary.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Course",
                columns: table => new
                {
                    CourseCode = table.Column<string>(type: "CHAR(4)", nullable: false),
                    CourseTitle = table.Column<string>(type: "VARCHAR(20)", nullable: false),
                    CourseDuration = table.Column<int>(type: "int", nullable: false),
                    CourseFee = table.Column<decimal>(type: "MONEY", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Course", x => x.CourseCode);
                });

            migrationBuilder.CreateTable(
                name: "Batch",
                columns: table => new
                {
                    BatchCode = table.Column<string>(type: "CHAR(5)", nullable: false),
                    CourseCode = table.Column<string>(type: "CHAR(4)", nullable: false),
                    StartDate = table.Column<DateTime>(type: "DATETIME", nullable: false),
                    EndDate = table.Column<DateTime>(type: "DATETIME", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Batch", x => x.BatchCode);
                    table.ForeignKey(
                        name: "FK_Batch_Course_CourseCode",
                        column: x => x.CourseCode,
                        principalTable: "Course",
                        principalColumn: "CourseCode",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Student",
                columns: table => new
                {
                    RollNo = table.Column<int>(type: "int", nullable: false),
                    BatchCode = table.Column<string>(type: "CHAR(5)", nullable: false),
                    StudentName = table.Column<string>(type: "VARCHAR(30)", nullable: false),
                    StudentAddress = table.Column<string>(type: "VARCHAR(50)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Student", x => x.RollNo);
                    table.ForeignKey(
                        name: "FK_Student_Batch_BatchCode",
                        column: x => x.BatchCode,
                        principalTable: "Batch",
                        principalColumn: "BatchCode",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Batch_CourseCode",
                table: "Batch",
                column: "CourseCode");

            migrationBuilder.CreateIndex(
                name: "IX_Student_BatchCode",
                table: "Student",
                column: "BatchCode");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Student");

            migrationBuilder.DropTable(
                name: "Batch");

            migrationBuilder.DropTable(
                name: "Course");
        }
    }
}
