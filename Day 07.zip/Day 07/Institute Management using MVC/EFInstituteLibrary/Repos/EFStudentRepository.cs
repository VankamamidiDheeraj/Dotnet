﻿using EFInstituteLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFInstituteLibrary.Repos
{
    public class EFStudentRepository : IStudentRepository {
        ZelisInstituteDBContext ctx = new ZelisInstituteDBContext();
        public void DeleteStudent(int rollNo) {
            Student stud2del = GetStudent(rollNo);
            try {
                ctx.Students.Remove(stud2del);
                ctx.SaveChanges();
            }
            catch (Exception ex) {
                throw new InstituteException(ex.Message);
            }
        }
        public List<Student> GetAllStudents() {
            List<Student> students = ctx.Students.ToList();
            return students;
        }
        public Student GetStudent(int rollNo) {
            try {
                Student student = (from s in ctx.Students where s.RollNo == rollNo select s).First();
                return student;
            }
            catch {
                throw new InstituteException("Student not found");
            }
        }
        public List<Student> GetStudentsByBatch(string bcode) {
            List<Student> students = (from s in ctx.Students where s.BatchCode == bcode select s).ToList();
            if (students.Count == 0) {
                throw new InstituteException("No students found for the given batch code");
            }
            else {
                return students;
            }
        }
        public void InsertStudent(Student student) {
            try {
                ctx.Students.Add(student);
                ctx.SaveChanges();
            }
            catch (Exception ex) {
                throw new InstituteException(ex.Message);
            }   
        }
        public void UpdateStudent(int rollNo, Student student) {
            Student stud2edit = GetStudent(rollNo);
            try {
                stud2edit.BatchCode = student.BatchCode;
                stud2edit.StudentName = student.StudentName;
                stud2edit.StudentAddress = student.StudentAddress;
                ctx.SaveChanges();
            }
            catch (Exception ex) {
                throw new InstituteException(ex.Message);
            }
        }
    }
}
