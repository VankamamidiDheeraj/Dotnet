﻿using EFInstituteLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFInstituteLibrary.Repos
{
    public class EFCourseRepository : ICourseRepository {
        ZelisInstituteDBContext ctx = new ZelisInstituteDBContext();
        public void DeleteCourse(string ccode) {
            Course course2del = GetCourse(ccode);
            try {
                ctx.Courses.Remove(course2del);
                ctx.SaveChanges();
            }
            catch (Exception ex) {
                throw new InstituteException(ex.Message);
            }
        }
        public List<Course> GetAllCourses() {
            List<Course> courses = ctx.Courses.ToList();
            return courses;
        }
        public Course GetCourse(string ccode) {
            try {
                Course course = (from c in ctx.Courses where c.CourseCode == ccode select c).First();
                return course;
            }
            catch {
                throw new InstituteException("Course not found");
            }
        }
        public void InsertCourse(Course course) {
            try {
                ctx.Courses.Add(course);
                ctx.SaveChanges();
            }
            catch (Exception ex) {
                throw new InstituteException(ex.Message);
            }
        }
        public void UpdateCourse(string ccode, Course course) {
            Course course2edit = GetCourse(ccode);
            try {
                course2edit.CourseTitle = course.CourseTitle;
                course2edit.CourseDuration = course.CourseDuration;
                course2edit.CourseFee = course.CourseFee;
                ctx.SaveChanges();
            }
            catch (Exception ex) {
                throw new InstituteException(ex.Message);
            }
        }
    }
}
