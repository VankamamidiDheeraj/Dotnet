﻿using EFInstituteLibrary.Models;
using EFInstituteLibrary.Repos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace InstituteMvcApp.Controllers {
    public class BatchController : Controller {
        IBatchRepository batchRepo;
        public BatchController(IBatchRepository repository) {
            batchRepo = repository;
        }
        public ActionResult Index() {
            List<Batch> batches = batchRepo.GetAllBatches();
            return View(batches);
        }
        public ActionResult Details(string bcode) {
            Batch batch = batchRepo.GetBatch(bcode);
            return View(batch);
        }
        public ActionResult Create() {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Batch batch) {
            try {
                batchRepo.InsertBatch(batch);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        [Route("Batch/Edit/{bcode}")]
        public ActionResult Edit(string bcode) {
            Batch batch = batchRepo.GetBatch(bcode);
            return View(batch);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Batch/Edit/{bcode}")]
        public ActionResult Edit(string bcode, Batch batch) {
            try {
                batchRepo.UpdateBatch(bcode, batch);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        [Route("Batch/Delete/{bcode}")]
        public ActionResult Delete(string bcode) {
            Batch batch = batchRepo.GetBatch(bcode);
            return View(batch);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Batch/Delete/{bcode}")]
        public ActionResult Delete(string bcode, IFormCollection collection) {
            try {
                batchRepo.DeleteBatch(bcode);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        public ActionResult BatchesByCourse(string ccode) {
            List<Batch> batches = batchRepo.GetBatchesByCourse(ccode);
            return View(batches);
        }
    }
}
