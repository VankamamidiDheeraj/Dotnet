﻿using EFInstituteLibrary.Models;
using EFInstituteLibrary.Repos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace InstituteMvcApp.Controllers {
    public class StudentController : Controller {
        IStudentRepository studentRepo;
        public StudentController(IStudentRepository repository) {
            studentRepo = repository;
        }
        public ActionResult Index() {
            List<Student> students = studentRepo.GetAllStudents();
            return View(students);
        }
        public ActionResult Details(int rno) {
            Student student = studentRepo.GetStudent(rno);
            return View(student);
        }
        public ActionResult Create() {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Student student) {
            try {
                studentRepo.InsertStudent(student);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        [Route("Student/Edit/{rno}")]
        public ActionResult Edit(int rno) {
            Student student = studentRepo.GetStudent(rno);
            return View(student);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Student/Edit/{rno}")]
        public ActionResult Edit(int rno, Student student) {
            try {
                studentRepo.UpdateStudent(rno, student);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        [Route("Student/Delete/{rno}")]
        public ActionResult Delete(int rno) {
            Student student = studentRepo.GetStudent(rno);
            return View(student);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Student/Delete/{rno}")]
        public ActionResult Delete(int rno, IFormCollection collection) {
            try {
                studentRepo.DeleteStudent(rno);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        public ActionResult StudentsByBatch(string bcode) {
            List<Student> students = studentRepo.GetStudentsByBatch(bcode);
            return View(students);
        }
    }
}
