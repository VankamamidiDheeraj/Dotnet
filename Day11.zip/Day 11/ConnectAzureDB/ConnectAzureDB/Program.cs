﻿using Microsoft.Data.SqlClient;

namespace ConnectAzureDB
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"Server=tcp:sqlsvr-snrao.database.windows.net,1433;Initial Catalog=EmpDB-snrao;Persist Security Info=False;User ID=snrao;Password=Welcome@1234;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
            try
            {
                con.Open();
                Console.WriteLine("Connected to Azure Database successfully");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
