﻿namespace EmpMvcApp.Models
{
    public class Employee
    {
        public int EmpId { get; set; }

        public string EmpName { get; set; } = null!;

        public decimal? Salary { get; set; }
    }
}
