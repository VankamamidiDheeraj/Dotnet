﻿//using EmpLibrary.Models;
//using EmpLibrary.Repos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EmpMvcApp.Models;
using System.Threading.Tasks;
namespace EmpMvcApp.Controllers {
    public class EmployeeController : Controller {
        //static HttpClient client = new HttpClient() { BaseAddress = new Uri("https://samplewebapi-snrao-g5h5eahudqhxcqga.canadacentral-01.azurewebsites.net/api/employee/") };
        static HttpClient client = new HttpClient() { BaseAddress = new Uri("https://apimgmt-snrao.azure-api.net/emp/api/Employee?subscription-key=abf1f1ca7e0848e7a034e07a6c570c21") };
        public async Task<ActionResult> Index() {
            List<Employee> employees = await client.GetFromJsonAsync<List<Employee>>("");
            return View(employees);
        }
        public ActionResult Details(int id) {
            return View();
        }
        public ActionResult Create() {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Employee employee) {
            try {
                await client.PostAsJsonAsync<Employee>("", employee);
                return RedirectToAction(nameof(Index));
            }
            catch  {
                return View();
            }
        }

        // GET: EmployeeController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: EmployeeController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EmployeeController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: EmployeeController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
