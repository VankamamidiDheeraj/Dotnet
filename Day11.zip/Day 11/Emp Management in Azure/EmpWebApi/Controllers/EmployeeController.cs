﻿using EmpLibrary.Models;
using EmpLibrary.Repos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EmpWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        IEmployeeRepository empRepo;
        public EmployeeController(IEmployeeRepository repository)
        {
            empRepo = repository;
        }
        [HttpGet]
        public ActionResult GetAll()
        {
            List<Employee> employees = empRepo.GetAllEmployees();
            return Ok(employees);
        }
        [HttpPost]
        public ActionResult Add(Employee employee)
        {
            try
            {
                empRepo.InsertEmployee(employee);
                return Created($"api/Employee/{employee.EmpId}", employee);
            }
            catch (EmpException ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
