﻿using Microsoft.AspNetCore.Html;
using System.Web;

namespace EmployeeMvcApp.Helpers
{
    public class LabelHelper
    {
        public static HtmlString MyLabel(string targetId, string text)
        {
            string label = $"<label for='{targetId}'>{text}</label>";
            return new HtmlString(label);
        }
    }
}
