﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewFeatures;

namespace EmployeeMvcApp.Helpers
{
    public static class ImageHelper
    {
        public static HtmlString MyImage(this IHtmlHelper hh, string id, string path, string text, object attributes = null )
        {
            TagBuilder tag = new TagBuilder("IMG");
            tag.GenerateId("ID", id);
            tag.MergeAttribute("SRC", path);
            tag.MergeAttribute("ALT", text);
            tag.MergeAttributes(new RouteValueDictionary(attributes));
            var writer = new StringWriter();
            tag.WriteTo(writer, System.Text.Encodings.Web.HtmlEncoder.Default);
            string result = writer.ToString();
            return new HtmlString(result);
        }
    }
}
