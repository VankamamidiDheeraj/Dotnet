﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
//using EFEmployeeLibray.Models;
//using EFEmployeeLibray.Repos;
using EmployeeMvcApp.Filters;
using EmployeeMvcApp.Models;
using System.Threading.Tasks;
namespace EmployeeMvcApp.Controllers {
    //[TypeFilter(typeof(LogActionFilterAttribute))]
    //[LogActionFilter]
    [TypeFilter(typeof(CustomExceptionFilter))]
    public class EmployeeController : Controller {
        private readonly ILogger<EmployeeController> _logger;
        //IEmployeeRepository empRepo;
        static HttpClient client = new HttpClient() { BaseAddress = new Uri("http://localhost:5289/api/Employee/") };
        public EmployeeController(ILogger<EmployeeController> logger) {
            //empRepo = repository;
            _logger = logger;
        }
        //[LogActionFilter]
        public async Task<ActionResult> Index() {
            _logger.LogInformation("Fetching all employees");
            List<Employee> employees = await client.GetFromJsonAsync<List<Employee>>("");
            return View(employees);
        }
        public async Task<ActionResult> Details(int id) {
            _logger.LogInformation($"Fetching details for employee ID: {id}");
            Employee employee = await client.GetFromJsonAsync<Employee>("" + id);
            return View(employee);
        }
        public ActionResult Create() {
            Employee emp = new Employee();
            return View(emp);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Employee emp) {
            //empRepo.InsertEmployee(emp);
            await client.PostAsJsonAsync<Employee>("", emp);
            return RedirectToAction(nameof(Index));
        }
        public async Task<ActionResult> Edit(int id) {
            Employee employee = await client.GetFromJsonAsync<Employee>("" + id);
            return View(employee);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(int id, Employee emp) {
            //empRepo.UpdateEmployee(id, emp);
            await client.PutAsJsonAsync<Employee>("" + id, emp);
            return RedirectToAction(nameof(Index));
        }
        public async Task<ActionResult> Delete(int id) {
            Employee employee = await client.GetFromJsonAsync<Employee>("" + id);
            return View(employee);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Delete(int id, IFormCollection collection) {
            //empRepo.DeleteEmployee(id);
            await client.DeleteAsync("" + id);
            return RedirectToAction(nameof(Index));
        }
    }
}
