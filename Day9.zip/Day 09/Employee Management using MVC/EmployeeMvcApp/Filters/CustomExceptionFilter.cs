﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.ViewFeatures;

namespace EmployeeMvcApp.Filters
{
    public class CustomExceptionFilter : IExceptionFilter
    {
        private readonly IModelMetadataProvider provider;
        public CustomExceptionFilter(IModelMetadataProvider immp)
        {
            provider = immp;
        }
        public void OnException(ExceptionContext context)
        {
            var result = new ViewResult { ViewName = "Error" };
            result.ViewData = new ViewDataDictionary(provider, context.ModelState);
            result.ViewData.Add("ErrorMessage", context.Exception.Message);
            context.ExceptionHandled = true;
            context.Result = result;
        }
    }
}
