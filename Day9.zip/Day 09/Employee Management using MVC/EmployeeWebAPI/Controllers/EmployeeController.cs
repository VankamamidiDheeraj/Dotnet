﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EFEmployeeLibray.Models;
using EFEmployeeLibray.Repos;

namespace EmployeeWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase {
        IEmployeeRepository empRepo;
        public EmployeeController(IEmployeeRepository repository) {
            empRepo = repository;
        }
        [HttpGet]
        public ActionResult GetAll() {
            List<Employee> employees = empRepo.GetAllEmployees();
            return Ok(employees);
        }
        [HttpGet("{id}")]
        public ActionResult Get(int id) {
            try {
                Employee employee = empRepo.GetEmployee(id);
                return Ok(employee);
            }
            catch (EmpException ex) {
                return NotFound(ex.Message);
            }
        }
        [HttpPost]
        public ActionResult Post(Employee employee) { 
            try {
                empRepo.InsertEmployee(employee);
                return Created($"api/Employee/{employee.EmpId}", employee);
            }
            catch (EmpException ex) {
                return BadRequest(ex.Message);
            }
        }
        [HttpPut("{id}")]
        public ActionResult Update(int id, Employee employee) {
            try {
                empRepo.UpdateEmployee(id, employee);
                return Ok(employee);
            }
            catch (EmpException ex) {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public ActionResult Delete(int id) {
            try {
                empRepo.DeleteEmployee(id);
                return Ok();
            }
            catch (EmpException ex) {
                return BadRequest(ex.Message);
            }
        }
    }
}
