﻿using EFInstituteLibrary.Models;
using EFInstituteLibrary.Repos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace InstituteWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BatchController : ControllerBase {
        IBatchRepository batchRepo;
        public BatchController(IBatchRepository repository) {
            batchRepo = repository;
        }
        [HttpGet]
        public ActionResult GetAll() {
            List<Batch> batches = batchRepo.GetAllBatches();
            return Ok(batches);
        }
        [HttpGet("ByBatchCode/{bcode}")]
        public ActionResult Get(string bcode) {
            try {
                Batch batch = batchRepo.GetBatch(bcode);
                return Ok(batch);
            }
            catch (InstituteException ex) {
                return NotFound(ex.Message);
            }
        }
        [HttpGet("ByCourseCode/{ccode}")]
        public ActionResult GetByCourse(string ccode) {
            try {
                List<Batch> batches = batchRepo.GetBatchesByCourse(ccode);
                return Ok(batches);
            }
            catch (InstituteException ex) {
                return NotFound(ex.Message);
            }
        }
        [HttpPost]
        public ActionResult Insert(Batch batch) {
            try {
                batchRepo.InsertBatch(batch);
                return Created($"api/Batch/{batch.BatchCode}", batch);
            }
            catch (InstituteException ex) {
                return BadRequest(ex.Message);
            }
        }
        [HttpPut("{bcode}")]
        public ActionResult Update(string bcode, Batch batch) {
            try {
                batchRepo.UpdateBatch(bcode, batch);
                return Ok(batch);
            }
            catch (InstituteException ex) {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{bcode}")]
        public ActionResult Delete(string bcode) {
            try {
                batchRepo.DeleteBatch(bcode);
                return Ok();
            }
            catch (InstituteException ex) {
                return BadRequest(ex.Message);
            }
        }
    }
}
