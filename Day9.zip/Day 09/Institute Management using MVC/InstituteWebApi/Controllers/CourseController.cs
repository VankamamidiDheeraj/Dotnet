﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EFInstituteLibrary.Models;
using EFInstituteLibrary.Repos;
namespace InstituteWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase {
        ICourseRepository courseRepo;
        public CourseController(ICourseRepository repository) {
            courseRepo = repository;
        }
        [HttpGet]
        public ActionResult GetAll() {
            List<Course> courses = courseRepo.GetAllCourses();
            return Ok(courses);
        }
        [HttpGet("{ccode}")]
        public ActionResult Get(string ccode) {
            try {
                Course course = courseRepo.GetCourse(ccode);
                return Ok(course);
            }
            catch (InstituteException ex) {
                return NotFound(ex.Message);
            }
        }
        [HttpPost]
        public ActionResult Insert(Course course) {
            try {
                courseRepo.InsertCourse(course);
                return Created($"api/Course/{course.CourseCode}", course);
            }
            catch (InstituteException ex) {
                return BadRequest(ex.Message);
            }
        }
        [HttpPut("{ccode}")]
        public ActionResult Update(string ccode, Course course) {
            try {
                courseRepo.UpdateCourse(ccode, course);
                return Ok(course);
            }
            catch (InstituteException ex) {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{ccode}")]
        public ActionResult Delete(string ccode) {
            try {
                courseRepo.DeleteCourse(ccode);
                return Ok();
            }
            catch (InstituteException ex) {
                return BadRequest(ex.Message);
            }
        }
    }
}
