﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFInstituteLibrary.Models
{
    public class ZelisInstituteDBContext : DbContext
    {
        public ZelisInstituteDBContext()
        {
        }
        public ZelisInstituteDBContext(DbContextOptions<ZelisInstituteDBContext> options) : base(options)
        {
        }
        public DbSet<Course> Courses { get; set; }
        public DbSet<Batch> Batches { get; set; }
        public DbSet<Student> Students { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"data source=(localdb)\MSSQLLocalDB; database=ZelisInstituteDB; integrated security=true");
        }
    }
}
