﻿using EFInstituteLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFInstituteLibrary.Repos {
    public class EFBatchRepository : IBatchRepository {
        ZelisInstituteDBContext ctx = new ZelisInstituteDBContext();
        public void DeleteBatch(string bcode) {
            Batch batch2del = GetBatch(bcode);
            try {
                ctx.Batches.Remove(batch2del);
                ctx.SaveChanges();
            }
            catch (Exception ex) {
                throw new InstituteException(ex.Message);
            }
        }
        public List<Batch> GetAllBatches() {
            List<Batch> batches = ctx.Batches.ToList();
            return batches;
        }
        public Batch GetBatch(string bcode) {
            try {
                Batch batch = (from b in ctx.Batches where b.BatchCode == bcode select b).First();
                return batch;
            }
            catch {
                throw new InstituteException("Batch not found");
            }
        }
        public List<Batch> GetBatchesByCourse(string ccode) {
            List<Batch> batches = (from b in ctx.Batches where b.CourseCode == ccode select b).ToList();
            if (batches.Count == 0) {
                throw new InstituteException("No batches found for the given course code");
            }
            else {
                return batches;
            }
        }
        public void InsertBatch(Batch batch) {
            try {
                ctx.Batches.Add(batch);
                ctx.SaveChanges();
            }
            catch (Exception ex) {
                throw new InstituteException(ex.Message);
            }
        }
        public void UpdateBatch(string bcode, Batch batch) {
            Batch batch2edit = GetBatch(bcode);
            try {
                batch2edit.CourseCode = batch.CourseCode;
                batch2edit.StartDate = batch.StartDate;
                batch2edit.EndDate = batch.EndDate;
                ctx.SaveChanges();
            }
            catch (Exception ex) {
                throw new InstituteException(ex.Message);
            }
        }
    }
}
