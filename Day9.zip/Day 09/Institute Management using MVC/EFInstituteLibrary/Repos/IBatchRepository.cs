﻿using EFInstituteLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFInstituteLibrary.Repos
{
    public interface IBatchRepository
    {
        void InsertBatch(Batch batch);
        void UpdateBatch(string bcode, Batch batch);
        void DeleteBatch(string bcode);
        Batch GetBatch(string bcode);
        List<Batch> GetAllBatches();
        List<Batch> GetBatchesByCourse(string ccode);
    }
}
