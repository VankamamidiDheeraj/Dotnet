﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EFInstituteLibrary.Models;
using EFInstituteLibrary.Repos;
namespace InstituteMvcApp.Controllers {
    public class CourseController : Controller {
        ICourseRepository courseRepo;
        public CourseController(ICourseRepository repository) {
            courseRepo = repository;
        }
        public ActionResult Index() {
            List<Course> courses = courseRepo.GetAllCourses();
            return View(courses);
        }
        public ActionResult Details(string ccode) {
            Course course = courseRepo.GetCourse(ccode);
            return View(course);
        }
        public ActionResult Create() {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Course course) {
            try {
                courseRepo.InsertCourse(course);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        [Route("Course/Edit/{ccode}")]
        public ActionResult Edit(string ccode) {
            Course course = courseRepo.GetCourse(ccode);
            return View(course);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Course/Edit/{ccode}")]
        public ActionResult Edit(string ccode, Course course) {
            try {
                courseRepo.UpdateCourse(ccode, course);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        [Route("Course/Delete/{ccode}")]
        public ActionResult Delete(string ccode) {
            Course course = courseRepo.GetCourse(ccode);
            return View(course);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Course/Delete/{ccode}")]
        public ActionResult Delete(string ccode, IFormCollection collection) {
            try {
                courseRepo.DeleteCourse(ccode);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
    }
}
