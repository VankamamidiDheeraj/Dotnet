﻿using EFInstituteLibrary.Models;
using EFInstituteLibrary.Repos;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace InstituteMvcApp.Models
{
    public class InstituteHelper
    {
        public static List<SelectListItem> GetCourseCodes()
        {
            List<SelectListItem> courseCodes = new List<SelectListItem>();
            ICourseRepository courseRepo = new EFCourseRepository();
            List<Course> courses = courseRepo.GetAllCourses();
            foreach (Course course in courses)
            {
                SelectListItem item = new SelectListItem()
                {
                    Text = course.CourseTitle,
                    Value = course.CourseCode
                };
                courseCodes.Add(item);
            }
            return courseCodes;
        }
        public static List<SelectListItem> GetBatchCodes()
        {
            List<SelectListItem> batchCodes = new List<SelectListItem>();
            IBatchRepository batchRepo = new EFBatchRepository();
            List<Batch> batches = batchRepo.GetAllBatches();
            foreach (Batch batch in batches)
            {
                SelectListItem item = new SelectListItem()
                {
                    Text = batch.BatchCode,
                    Value = batch.BatchCode
                };
                batchCodes.Add(item);
            }
            return batchCodes;
        }
    }
}
