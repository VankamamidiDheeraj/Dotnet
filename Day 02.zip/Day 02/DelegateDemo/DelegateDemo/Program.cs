﻿namespace DelegateDemo {
    class Arithmetic {
        public int Add(int x, int y) {
            return x + y;
        }
        public int Subtract(int x, int y) {
            return x - y;
        }
        public int Multiply(int x, int y) {
            return x * y;
        }
    }
    delegate int MyDel(int x, int y);   // Declare the delegate
    internal class Program {
        static void Main(string[] args) {
            Arithmetic arith = new Arithmetic();
            MyDel delObj;       // Declare the delegate object
            delObj = new MyDel(arith.Subtract); // Point to a method
            int res = delObj(8, 3); // Call the method
            delObj = new MyDel(arith.Add);  // Point to another method
            res = delObj(8, 3);
        }
    }
}
