﻿namespace GenericDemo
{
    internal class Program
    {
        /*static void Swap(ref int x, ref int y)
        {
            int t = x;
            x = y;
            y = t;
        }*/
        /*static void Swap(ref object x, ref object y)
        {
            object t = x;
            x = y;
            y = t;
        }*/
        static void Swap<T>(ref T x, ref T y) { // Generic Method
            T t;
            t = x;
            x = y;
            y = t;
        }
        class MyCollecion<T> {      // Generic Class
            List<T> list = new List<T>();
            public T this[int i]
            {
                get { return list[i]; }
                set { list.Add(value);  }
            }
        }
        static void Main(string[] args) {
            int a, b;
            a = 4;  b = 5;
            Swap<int>(ref a, ref b);
            double c, d;
            c = 12.34;  d = 3.76;
            Swap(ref c, ref d);
            MyCollecion<int> collecion1 = new MyCollecion<int>();
            collecion1[0] = 5;
            //collecion1[1] = "Apple";
            MyCollecion<string> collecion2 = new MyCollecion<string>();
            collecion2[0] = "Apple";
            //collecion2[1] = 5;
        }
    }
}
