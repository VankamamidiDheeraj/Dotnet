﻿namespace CSharp2Demo {
    static class Sample {
        static int num;
        public static void Method1() { }
        static Sample() { }
    }
    //class Example : Sample { }
    partial class Employee {
        public void Method1() { }
    }
    partial class Employee {
        public void Method2() { }
        private int empId;
        public int EmpId {  // Property with multiple access modifiers
            get { return empId; }
            protected set { empId = value; }
        }
    }
    internal class Program {
        static void Main(string[] args) {
            //Sample obj;
            Sample.Method1();
            Employee emp = new Employee();
            //emp.EmpId = 101;
            Console.WriteLine(emp.EmpId);
            emp.Method1();
            emp.Method2();
            emp = null;
            int? num = null;    // Nullable type
        }
    }
}
