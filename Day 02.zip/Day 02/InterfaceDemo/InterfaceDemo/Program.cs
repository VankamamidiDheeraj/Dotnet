﻿namespace InterfaceDemo {
    interface IShape {
        void Draw();
        double Area { get; }
    }
    interface IShape2 {
        void Paint();
    }
    class Circle : IShape, IShape2 {
        double radius;
        public double Area {
            get { return Math.PI * radius * radius; }
        }
        public void Draw() {
            Console.WriteLine($"Drawing a circle with radius {radius}");
        }
        public void Paint() {
            Console.WriteLine("Painting the circle");
        }
        public Circle(double rad) {
            radius = rad;
        }
    }
    class Rectangle : IShape {
        double length, breadth;
        public double Area { get { return length * breadth; } }
        public void Draw() {
            Console.WriteLine($"Drawing a rectangle with length {length} and breadth {breadth}");
        }
        public Rectangle(double len, double bre) {
            length = len;   breadth = bre;
        }
    }
    internal class Program {
        static void Main(string[] args) {
            Circle shape;
            shape = new Circle(6.2);
            shape.Draw();
            Console.WriteLine($"Area of the circle is {shape.Area}");
            shape.Paint();
        }
    }
}
