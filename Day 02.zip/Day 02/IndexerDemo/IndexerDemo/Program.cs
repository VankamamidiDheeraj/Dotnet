﻿namespace IndexerDemo { 
    class Student {
        private string name;
        public string Name {
            get { return name; }
            set { name = value; }
        }
        private int[] marks = new int[5];
        public int this[int i]      // Indexer
        {
            get { return marks[i]; }
            set { marks[i] = value; }
        }
        public string[] subjects = new string[5];
        private int[,] matrix = new int[4, 3];
        public int this[int r, int c]   // Indexer Overloading
        {
            get { return matrix[r,c]; }
            set { matrix[r,c] = value; }
        }
    }
    internal class Program {
        static void Main(string[] args) {
            Student student = new Student();
            Console.Write("Enter name: ");
            student.Name = Console.ReadLine();
            for (int i = 0; i < 5; i++) {
                Console.Write("Enter marks: ");
                student[i] = Convert.ToInt32(Console.ReadLine());
            }
        }
    }
}
