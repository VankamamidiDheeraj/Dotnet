﻿namespace StaticDemo
{
    class Employee {
        private int empId;  // Instance Field
        public int EmpId {
            get { return empId; }
            set { empId = value; }
        }
        static int empCount; // Static Field
        public Employee() {
            empCount++;
        }
        public static int GetEmpCount() {   // Static Method
            //empId = 0;    // Error
            return empCount;
        }
        static Employee() {     // Static Constuctor
            empCount = 100;
        }
    }
    internal class Program {
        static void Main(string[] args) {
            //Console.WriteLine($"No. of emps = {Employee.empCount}");
            Console.WriteLine($"No. of emps = {Employee.GetEmpCount()}");
            Employee emp = new Employee();
            //Console.WriteLine($"No. of emps = {Employee.empCount}");
            Console.WriteLine($"No. of emps = {Employee.GetEmpCount()}");
            Employee emp2 = new Employee();
            //Console.WriteLine($"No. of emps = {Employee.empCount}");
            Console.WriteLine($"No. of emps = {Employee.GetEmpCount()}");
        }
    }
}
