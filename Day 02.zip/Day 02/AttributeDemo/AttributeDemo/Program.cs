﻿//#define DISPLAY

using System.Diagnostics;

namespace AttributeDemo
{
    class MyAttribute : Attribute { }
    internal class Program
    {
        [Conditional("DISPLAY")]
        static void PrintVariable(object x)
        {
            Console.WriteLine(x);
        }
        [My]
        static void Main(string[] args)
        {
            int num = 8;
            PrintVariable(num);
            string name = "Zelis";
            PrintVariable(name);
            DateTime today = DateTime.Now;
            PrintVariable(today);
        }
    }
}
