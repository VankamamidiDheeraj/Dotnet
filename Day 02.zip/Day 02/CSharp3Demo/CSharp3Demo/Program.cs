﻿namespace CSharp3Demo {
    class Employee {
        public int EmpId { get; set; }   // Automatic Property
        public string EmpName { get; set; }
        public decimal Salary { get; set; }
        public void AcceptDetails() { }
    }
    static class Xyz {
        public static void DisplayDetails(this Employee emp) { } // Extension Method
        public static bool IsValidEmail(this string s) {
            if (s.Contains('@'))
                return true;
            else
                return false;
        }
    }
    internal class Program {
        static void Main(string[] args) {
            string email = "abc@xyz.com";
            if (email.IsValidEmail())
                Console.WriteLine("Valid email");
            else
                Console.WriteLine("Invalid email");
            var num = 5;    // Implicitly typed local variable
            // Object Initializer
            Employee emp = new Employee() { EmpId = 101, EmpName = "Ramesh", Salary = 45000 };
            emp.AcceptDetails();
            emp.DisplayDetails();
            // Collection Initializer
            Employee emp2 = new Employee() { EmpId = 102, EmpName = "Devi", Salary = 46000 };
            List<Employee> employees = new List<Employee>() { emp, emp2, new Employee() { EmpId = 103, EmpName = "Suresh", Salary = 42000 } };
            // Anonymous Type
            var customer = new { CustId = 501, CustName = "Wipro", CustAddr = "Bengaluru" };
            Console.WriteLine($"Customer Id: {customer.CustId}, Name: {customer.CustName}, Address: {customer.CustAddr}");
            //customer.CustAddr = "Mysore"; // Properties in anonymous type are read-only
        }
    }
}
