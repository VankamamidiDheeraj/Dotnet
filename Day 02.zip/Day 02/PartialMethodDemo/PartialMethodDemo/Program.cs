﻿namespace PartialMethodDemo
{
    partial class Sample
    {
        partial void Method2();
        public void Method1()
        {
            Method2();
        }
    }
    partial class Sample
    {
        /*partial void Method2()
        {
        }*/
    }
    partial class ReportPrinter {
        partial void PrintHeader();
        partial void PrintFooter();
        public void PrintReport() {
            PrintHeader();
            PrintBody();
            PrintFooter();
        }
    }
    partial class ReportPrinter {
        private void PrintBody() { }
        partial void PrintHeader() { }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            ReportPrinter printer = new ReportPrinter();
            printer.PrintReport();
            Sample obj = new Sample();
            obj.Method1();
        }
    }
}
