﻿using EFEmployeeLibray.Models;
using EFEmployeeLibray.Repos;
namespace EmployeeApp { 
    internal class Program {
        //static IEmployeeRepository empRepo = new EmployeeRepository();
        //static IEmployeeRepository empRepo = new ADOEmployeeRepository();
        static IEmployeeRepository empRepo = new EFEmployeeRepository();
        static void Main(string[] args) {
            while(true) {
                Console.WriteLine("---------------");
                Console.WriteLine("--- M E N U ---");
                Console.WriteLine("---------------");
                Console.WriteLine("1. Add Employee");
                Console.WriteLine("2. View Employee");
                Console.WriteLine("3. View All Emps");
                Console.WriteLine("4. Update Employee");
                Console.WriteLine("5. Delete Employee");
                Console.WriteLine("6. Exit");
                Console.Write("Enter your choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice) {
                    case 1: AddEmployee();  break;
                    case 2: ViewEmployee(); break;
                    case 3: ViewAllEmps();  break;
                    case 4: UpdateEmployee();   break;
                    case 5: DeleteEmployee();   break;
                    case 6: return;
                }
            }
        }
        private static void DeleteEmployee() {
            Console.Write("Enter emp id to delete: ");
            int eid = Convert.ToInt32(Console.ReadLine());
            try {
                Employee emp = empRepo.GetEmployee(eid);
                Console.WriteLine($"Emp Id: {emp.EmpId}, Name: {emp.EmpName}, Salary: {emp.Salary}");
                Console.Write("Are you sure to delete? ");
                char ch = Convert.ToChar(Console.ReadLine());
                if (ch == 'y') {
                    empRepo.DeleteEmployee(eid);
                    Console.WriteLine("Employee deleted");
                }
            }
            catch (EmpException ex) {
                Console.WriteLine(ex.Message);
            }
        }
        private static void UpdateEmployee() {
            Console.Write("Enter emp id to update: ");
            int eid = Convert.ToInt32(Console.ReadLine());
            try {
                Employee emp = empRepo.GetEmployee(eid);
                Console.WriteLine($"Emp Id: {emp.EmpId}, Name: {emp.EmpName}, Salary: {emp.Salary}");
                Console.Write("Enter new name: ");
                emp.EmpName = Console.ReadLine();
                Console.Write("Enter new salary: ");
                emp.Salary = Convert.ToDecimal(Console.ReadLine());
                empRepo.UpdateEmployee(eid, emp);
                Console.WriteLine("Employee details updated");
            }
            catch (EmpException ex) {
                Console.WriteLine(ex.Message);
            }
        }
        private static void ViewAllEmps() {
            List<Employee> emps = empRepo.GetAllEmployees();
            Console.WriteLine("List of employees...");
            foreach (Employee emp in emps) {
                Console.WriteLine($"Emp Id: {emp.EmpId}, Name: {emp.EmpName}, Salary: {emp.Salary}");
            }
        }
        private static void ViewEmployee() {
            Console.Write("Enter emp id to view: ");
            int eid = Convert.ToInt32(Console.ReadLine());
            try {
                Employee emp = empRepo.GetEmployee(eid);
                Console.WriteLine($"Emp Id: {emp.EmpId}, Name: {emp.EmpName}, Salary: {emp.Salary}");
            }
            catch (EmpException ex) {
                Console.WriteLine(ex.Message);
            }
        }
        private static void AddEmployee() {
            Employee emp = new Employee();
            Console.Write("Enter emp id: ");
            emp.EmpId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter name: ");
            emp.EmpName = Console.ReadLine();
            Console.Write("Enter salary: ");
            emp.Salary=Convert.ToDecimal(Console.ReadLine());
            empRepo.InsertEmployee(emp);
            Console.WriteLine("New employee added");
        }
    }
}
