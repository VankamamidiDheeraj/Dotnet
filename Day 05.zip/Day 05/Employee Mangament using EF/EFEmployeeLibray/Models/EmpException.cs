﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFEmployeeLibray.Models
{
    public class EmpException : Exception
    {
        public EmpException(string errMsg) : base(errMsg) { }
    }
}
