﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCustomerLibrary.Models
{
    [Table("Customer")]
    public class Customer
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int CustomerId { get; set; }
        [Column(TypeName = "VARCHAR(40)")]
        [Required]
        public string CustomerName { get; set; }
        [Column(TypeName = "VARCHAR(50)")]
        public string CustomerAddress { get; set; }
    }
}
