﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFStudentLibrary.Models
{
    public class ZelisStudentDBContext : DbContext
    {
        public ZelisStudentDBContext()
        {
            
        }
        public ZelisStudentDBContext(DbContextOptions<ZelisStudentDBContext> options) : base(options)
        {

        }   
        public virtual DbSet<Student> Students { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("data source=(localdb)\\MSSQLLocalDB; Database=ZelisStudentDB; integrated security=true");
        }
    }
}
