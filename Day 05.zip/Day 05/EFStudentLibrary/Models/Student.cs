﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFStudentLibrary.Models
{
    [Table("Student")]
    public class Student
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int RollNo { get; set; }
        [Column(TypeName = "VARCHAR(30)")]
        [Required]
        public string StudentName { get; set; }
        [Column(TypeName = "VARCHAR(50)")]
        public string Address { get; set; }
        [Column(TypeName = "MONEY")]
        public decimal TotalFee { get; set; }
    }
}
