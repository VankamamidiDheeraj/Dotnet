﻿namespace EFStudentLibrary;

public class Class1
{

}
