﻿using EFInstituteLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFInstituteLibrary.Repos
{
    public interface ICourseRepository
    {
        void InsertCourse(Course course);
        void UpdateCourse(string ccode, Course course);
        void DeleteCourse(string ccode);
        Course GetCourse(string ccode);
        List<Course> GetAllCourses();
    }
}
