﻿using EFInstituteLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFInstituteLibrary.Repos
{
    public interface IStudentRepository
    {
        void InsertStudent(Student student);
        void UpdateStudent(int rollNo, Student student);
        void DeleteStudent(int rollNo);
        Student GetStudent(int rollNo);
        List<Student> GetAllStudents();
        List<Student> GetStudentsByBatch(string bcode);
    }
}
