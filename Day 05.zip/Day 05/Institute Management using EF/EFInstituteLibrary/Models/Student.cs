﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFInstituteLibrary.Models
{
    [Table("Student")]
    public class Student
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int RollNo { get; set; }
        [Column(TypeName = "CHAR(5)")]
        [ForeignKey("Batch")]
        public string BatchCode { get; set; }
        [Column(TypeName = "VARCHAR(30)")]
        [Required]
        public string StudentName { get; set; }
        [Column(TypeName = "VARCHAR(50)")]
        public string StudentAddress { get; set; }

        public virtual Batch Batch { get; set; }
    }
}
