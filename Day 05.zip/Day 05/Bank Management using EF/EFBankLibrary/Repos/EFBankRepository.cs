﻿using EFBankLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFBankLibrary.Repos
{
    public class EFBankRepository : IBankRepository
    {
        ZelisBankDBContext ctx = new ZelisBankDBContext();
        public void DepositAmount(string accno, decimal amt)
        {
            try
            {
                ctx.SBTransactions.Add(new SBTransaction()
                {
                    AccountNumber = accno,
                    Amount = amt,
                    TransactionDate = DateTime.Now,
                    TransactionType = "D"
                });
                SBAccount account = GetAccount(accno);
                account.CurrentBalance += amt;
                ctx.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new BankException(ex.Message);
            }
        }
        public SBAccount GetAccount(string accno)
        {
            try
            {
                SBAccount account = (from a in ctx.SBAccounts where a.AccountNumber == accno select a).First();
                return account;
            }
            catch
            {
                throw new BankException("Account number not found");
            }
        }
        public List<SBAccount> GetAllAccounts() {
            List<SBAccount> accounts = ctx.SBAccounts.ToList();
            return accounts;
        }
        public List<SBTransaction> GetTransactions(string accno) {
            List<SBTransaction> transactions = (from t in ctx.SBTransactions where t.AccountNumber == accno select t).ToList();
            return transactions;
        }
        public void InsertAccount(SBAccount account) {
            try {
                ctx.SBAccounts.Add(account);
                ctx.SaveChanges();
            }
            catch (Exception ex) {
                throw new BankException(ex.Message);
            }
        }
        public void WithdrawAmount(string accno, decimal amt) {
            SBAccount account = GetAccount(accno);
            if (account.CurrentBalance < amt) {
                throw new BankException("Insufficient balance");
            }
            else {
                try {
                    ctx.SBTransactions.Add(new SBTransaction() {
                        AccountNumber = accno,
                        Amount = amt,
                        TransactionDate = DateTime.Now,
                        TransactionType = "W"
                    });
                    account.CurrentBalance -= amt;
                    ctx.SaveChanges();
                }
                catch (Exception ex) {
                    throw new BankException(ex.Message);
                }
            }
        }
    }
}