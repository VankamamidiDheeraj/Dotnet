﻿cREATE TABLE Product (
	ProductID INT PRIMARY KEY,
	ProductName VARCHAR(30) NOT NULL,
	Category VARCHAR(20),
	Price MONEY
);