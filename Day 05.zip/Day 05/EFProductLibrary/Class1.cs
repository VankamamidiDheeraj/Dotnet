﻿namespace EFProductLibrary;

public class Class1
{

}
