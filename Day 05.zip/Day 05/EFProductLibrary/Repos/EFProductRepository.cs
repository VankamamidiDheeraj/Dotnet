﻿using EFProductLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFProductLibrary.Repos {
    public class EFProductRepository : IProductRepository {
        ZelisDBContext ctx = new ZelisDBContext();
        public void DeleteProduct(int id) {
            Product prod2del = GetProductById(id);
            try {
                ctx.Products.Remove(prod2del);
                ctx.SaveChanges();
            }
            catch (Exception ex) {
                throw new ProductException(ex.Message);
            }
        }
        public List<Product> GetAllProducts() {
            List<Product> prods = ctx.Products.ToList();
            return prods;
        }
        public Product GetProductById(int id) {
            try {
                Product product = (from p in ctx.Products where p.ProductID == id select p).First();
                return product;
            }
            catch {
                throw new ProductException("No such product id");
            }
        }
        public List<Product> GetProductsByCategory(string cat) {
            List<Product> prods = (from p in ctx.Products where p.Category == cat select p).ToList();
            if (prods.Count == 0) {
                throw new ProductException("No products in this category");
            }
            else {
                return prods;
            }
        }
        public void NewProduct(Product prod) {
            try {
                ctx.Products.Add(prod);
                ctx.SaveChanges();
            }
            catch (Exception ex) {
                throw new ProductException(ex.Message);
            }
        }
        public void UpdateProduct(int id, Product prod) {
            Product prod2edit = GetProductById(id);
            prod2edit.ProductName = prod.ProductName;
            prod2edit.Category = prod.Category;
            prod2edit.Price = prod.Price;
            try {
                ctx.SaveChanges();
            }
            catch (Exception ex) {
                throw new ProductException(ex.Message);
            }
        }
    }
}
