﻿using EFProductLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFProductLibrary.Repos
{
    public interface IProductRepository
    {
        void NewProduct(Product prod);
        List<Product> GetAllProducts();
        List<Product> GetProductsByCategory(string cat);
        Product GetProductById(int id);
        void UpdateProduct(int id, Product prod);
        void DeleteProduct(int id);
    }
}
