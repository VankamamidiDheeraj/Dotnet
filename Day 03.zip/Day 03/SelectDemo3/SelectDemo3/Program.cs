﻿using Microsoft.Data.SqlClient;

namespace SelectDemo3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; database=ZelisDB; integrated security=true";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "SELECT * FROM EMPLOYEE";
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            Console.WriteLine("List of employees...");
            con.Close();
            while (reader.Read())
            {
                int eid = (int)reader["EmpId"];
                string ename = (string)reader["EmpName"];
                decimal sal = (decimal)reader["Salary"];
                Console.WriteLine($"Emp Id: {eid}, Name: {ename}, Salary: {sal}");
            }
            
        }
    }
}
