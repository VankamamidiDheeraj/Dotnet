﻿CREATE DATABASE ZelisDB

USE ZelisDB

CREATE TABLE Employee (
EmpId INT PRIMARY KEY,
EmpName VARCHAR(30) NOT NULL,
Salary MONEY)

INSERT INTO Employee VALUES(101, 'Ramesh', 45000)

SELECT * FROM Employee

UPDATE Employee SET EmpName='Ramesh Kumar', Salary=Salary+1000 WHERE EmpId=101

DELETE FROM Employee WHERE EmpId=102
