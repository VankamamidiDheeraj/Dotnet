﻿using Microsoft.Data.SqlClient;

namespace SelectDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; database=ZelisDB; integrated security=true";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            Console.Write("Enter emp id to view: ");
            int eid = Convert.ToInt32(Console.ReadLine());
            cmd.CommandText = $"SELECT EMPNAME FROM Employee WHERE EmpId = {eid}";
            // To execute SELECT statement returning a single value
            con.Open();
            string ename = (string)cmd.ExecuteScalar();
            if (string.IsNullOrEmpty(ename))
                Console.WriteLine("No such emp id");
            else
                Console.WriteLine($"Name: {ename}");
            con.Close();
        }
    }
}
