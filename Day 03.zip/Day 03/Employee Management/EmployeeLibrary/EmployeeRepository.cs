﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class EmployeeRepository : IEmployeeRepository {
        List<Employee> employees = new List<Employee>();
        public void DeleteEmployee(int eid) {
            Employee emp2del = GetEmployee(eid);
            employees.Remove(emp2del);
        }
        public List<Employee> GetAllEmployees() {
            return employees;
        }
        public Employee GetEmployee(int eid) {
            Employee emp = null;
            foreach (Employee e in employees) {
                if (e.EmpId == eid) {
                    emp = e;
                    break;
                }
            }
            if (emp == null)
                throw new EmpException("No such emp id");
            else
                return emp;
        }
        public void InsertEmployee(Employee employee) {
            employees.Add(employee);
        }
        public void UpdateEmployee(int eid, Employee employee) {
            Employee emp2edit = GetEmployee(eid);
            emp2edit.EmpName = employee.EmpName;
            emp2edit.Salary = employee.Salary;
        }
    }
}
