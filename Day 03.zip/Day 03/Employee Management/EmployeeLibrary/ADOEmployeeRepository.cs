﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
namespace EmployeeLibrary {
    public class ADOEmployeeRepository : IEmployeeRepository {
        SqlConnection con;
        SqlCommand cmd;
        public ADOEmployeeRepository() {
            con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; database=ZelisDB; integrated security=true";
            cmd = new SqlCommand();
            cmd.Connection = con;
        }
        public void DeleteEmployee(int eid) {
            cmd.CommandText = $"DELETE FROM EMPLOYEE WHERE EMPID={eid}";
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public List<Employee> GetAllEmployees() {
            cmd.CommandText = "SELECT * FROM EMPLOYEE";
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<Employee> employees = new List<Employee>();
            while (reader.Read()) {
                Employee emp = new Employee();
                emp.EmpId = (int)reader["EmpId"];
                emp.EmpName = (string)reader["EmpName"];
                emp.Salary = (decimal)reader["Salary"];
                employees.Add(emp);
            }
            con.Close();
            return employees;
        }
        public Employee GetEmployee(int eid) {
            cmd.CommandText = $"SELECT * FROM EMPLOYEE WHERE EMPID = {eid}";
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows) {
                reader.Read();
                Employee emp = new Employee();
                emp.EmpId = (int)reader["EmpId"];
                emp.EmpName = (string)reader["EmpName"];
                emp.Salary = (decimal)reader["Salary"];
                con.Close();
                return emp;
            }
            else {
                con.Close();
                throw new EmpException("No such emp id");
            }
        }
        public void InsertEmployee(Employee employee) {
            cmd.CommandText = $"INSERT INTO EMPLOYEE VALUES({employee.EmpId}, '{employee.EmpName}', {employee.Salary})";
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public void UpdateEmployee(int eid, Employee employee) {
            cmd.CommandText = $"UPDATE EMPLOYEE SET EMPNAME='{employee.EmpName}', SALARY={employee.Salary} WHERE EMPID={eid}";
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
