﻿using Microsoft.Data.SqlClient;

namespace SelectDemo2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; database=ZelisDB; integrated security=true";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            Console.Write("Enter emp id to view: ");
            int eid = Convert.ToInt32(Console.ReadLine());
            cmd.CommandText = $"SELECT EMPNAME, SALARY FROM EMPLOYEE WHERE EMPID={eid}";
            con.Open();
            // To execute SELECT statement returning multiple columns/rows
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows) {
                reader.Read();
                string ename = (string)reader["EmpName"];
                decimal sal = (decimal)reader["Salary"];
                Console.WriteLine($"Name: {ename}, Salary: {sal}");
            }
            else {
                Console.WriteLine("No such emp id");
            }
            con.Close();
        }
    }
}
