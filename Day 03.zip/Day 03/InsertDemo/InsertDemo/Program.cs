﻿using Microsoft.Data.SqlClient;

namespace InsertDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; database=ZelisDB; integrated security=true";
            Console.Write("Enter emp id: ");
            int eid = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter name: ");
            string ename = Console.ReadLine();
            Console.Write("Enter salary: ");
            decimal sal = Convert.ToDecimal(Console.ReadLine());
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            //cmd.CommandText = $"INSERT INTO Employee VALUES({eid}, '{ename}', {sal})";
            cmd.CommandText = "INSERT INTO Employees VALUES(@EMPID, @EMPNAME, @SALARY)";
            cmd.Parameters.AddWithValue("@EMPID", eid);
            cmd.Parameters.AddWithValue("@EMPNAME", ename);
            cmd.Parameters.AddWithValue("@SALARY", sal);
            con.Open();
            cmd.ExecuteNonQuery();  // To execute DML statements
            con.Close();
            Console.WriteLine("New employee added");
        }
    }
}
