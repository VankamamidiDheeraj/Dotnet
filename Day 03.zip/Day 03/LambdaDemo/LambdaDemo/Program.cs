﻿namespace LambdaDemo {
    class Employee {
        public int EmpId { get; set; }   // Automatic Property
        public string EmpName { get; set; }
        public decimal Salary { get; set; }
    }
    internal class Program {
        static void Main(string[] args) {
            List<Employee> employees = new List<Employee>() {
                new Employee() { EmpId = 101, EmpName = "Ramesh", Salary = 45000 },
                new Employee() { EmpId = 102, EmpName = "Devi", Salary = 46000 }, 
                new Employee() { EmpId = 103, EmpName = "Suresh", Salary = 42000 },
                new Employee() { EmpId = 104, EmpName = "Usha", Salary = 43000 },
                new Employee() { EmpId = 105, EmpName = "Sandhya", Salary = 46500 }
            };
            // Display emps getting above 45000
            /*List<Employee> emps = new List<Employee>();
            foreach (Employee emp in employees) {
                if (emp.Salary > 45000)
                    emps.Add(emp);
            }*/
            // Lambda
            //var emps = employees.Where(e => e.Salary > 45000);
            // LINQ
            var emps = from e in employees where e.Salary > 45000 select e;
            Console.WriteLine("Emps getting above 45000...");
            foreach (Employee emp in emps) {
                Console.WriteLine($"Emp Id: {emp.EmpId}, Name: {emp.EmpName}, Salary: {emp.Salary}");
            }
            // Display names of emps getting above 45000
            //var empnames = employees.Where(e => e.Salary > 45000).Select(e => e.EmpName);
            var empnames = from e in employees where e.Salary > 45000 select e.EmpName;
            Console.WriteLine("Names of emps getting above 45000...");
            foreach (string ename in empnames)
                Console.WriteLine($"Name: {ename}");
            // Display ids and names of emps getting above 45000
            //var eidsnames = employees.Where(e => e.Salary > 45000).Select(e => new { e.EmpId, e.EmpName });
            var eidsnames = from e in employees where e.Salary > 45000 select new { e.EmpId, e.EmpName };
            Console.WriteLine("Ids and names of emps getting above 45000...");
            foreach (var x in eidsnames)
                Console.WriteLine($"Emp Id: {x.EmpId}, Name: {x.EmpName}");
            Console.Write("Enter emp id: ");
            int eid = Convert.ToInt32(Console.ReadLine());
            try {
                //Employee employee = employees.Single(e => e.EmpId == eid);
                Employee employee = (from e in employees where e.EmpId == eid select e).First();
                Console.WriteLine($"Emp Id: {employee.EmpId}, Name: {employee.EmpName}, Salary: {employee.Salary}");
            }
            catch {
                Console.WriteLine("No such emp id");
            }
            //var emps2 = employees.OrderBy(e => e.EmpName);
            var emps2 = from e in employees orderby e.EmpName select e;
            Console.WriteLine("Sorted on emp names...");
            foreach (Employee emp in emps2)
                Console.WriteLine($"Emp Id: {emp.EmpId}, Name: {emp.EmpName}, Salary: {emp.Salary}");
            //var emps3 = employees.OrderByDescending(e => e.Salary);
            var emps3 = from e in employees orderby e.Salary descending select e;
            Console.WriteLine("Sorted in descending order of salary...");
            foreach (Employee emp in emps3)
                Console.WriteLine($"Emp Id: {emp.EmpId}, Name: {emp.EmpName}, Salary: {emp.Salary}");
        }
    }
}
