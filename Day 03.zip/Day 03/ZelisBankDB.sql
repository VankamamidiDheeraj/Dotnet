﻿CREATE DATABASE ZelisBankDB

USE ZelisBankDB

CREATE TABLE SBAccount (
AccountNumber CHAR(5) PRIMARY KEY,
CustomerName VARCHAR(30) NOT NULL,
CustomerAddress VARCHAR(30),
CurrentBalance MONEY)

CREATE TABLE SBTransaction (
TransactionId INT IDENTITY PRIMARY KEY,
AccountNumber CHAR(5) REFERENCES SBAccount(AccountNumber),
TransactionDate DATETIME,
Amount MONEY,
TransactionType CHAR(1) CHECK (TransactionType IN ('D','W')))

-- Add a new account
INSERT INTO SBAccount VALUES('12345', 'Raja', 'Ameerpet', 0)

-- Deposit Rs.5000/-
INSERT INTO SBTransaction VALUES('12345', GETDATE(), 5000, 'D')
UPDATE SBAccount SET CurrentBalance=CurrentBalance+5000 WHERE AccountNumber='12345'

SELECT * FROM SBAccount
SELECT * FROM SBTransaction

-- Withdraw Rs.2000/-
INSERT INTO SBTransaction VALUES('12345', GETDATE(), 2000, 'W')
UPDATE SBAccount SET CurrentBalance=CurrentBalance-2000 WHERE AccountNumber='12345'

INSERT INTO SBTransaction VALUES('11111', GETDATE(), 2000, 'W')	-- Error
	
DELETE FROM SBAccount WHERE AccountNumber='12345'	-- Error

UPDATE SBAccount SET AccountNumber='34567' WHERE AccountNumber='12345'	-- Error

SP_HELP SBAccount

SELECT AccountNumber, SUM(Amount) FROM SBTransaction WHERE TransactionType='D' GROUP By AccountNumber

SELECT AccountNumber, SUM(Amount) FROM SBTransaction WHERE TransactionType='D' 
	GROUP By AccountNumber HAVING SUM(Amount) > 3000






