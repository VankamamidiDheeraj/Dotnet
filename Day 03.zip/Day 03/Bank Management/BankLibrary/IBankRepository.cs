﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLibrary
{
    public interface IBankRepository
    {
        void InsertAccount(SBAccount account);
        List<SBAccount> GetAllAccounts();
        SBAccount GetAccount(string accno);
        void DepositAmount(string accno, decimal amt);
        void WithdrawAmount(string accno, decimal amt);
        List<SBTransaction> GetTransactions(string accno);
    }
}
