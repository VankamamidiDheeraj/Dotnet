﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
namespace BankLibrary
{
    public class ADOBankRepository : IBankRepository
    {
        SqlConnection con;
        SqlCommand cmd;
        public ADOBankRepository()
        {
            con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; database=ZelisBankDB; integrated security=true";
            cmd = new SqlCommand();
            cmd.Connection = con;
        }
        public void DepositAmount(string accno, decimal amt)
        {
            cmd.CommandText = $"INSERT INTO SBTRANSACTION VALUES('{accno}', '{DateTime.Now}', {amt}, 'D')";
            con.Open();
            cmd.ExecuteNonQuery();
            cmd.CommandText = $"UPDATE SBACCOUNT SET CURRENTBALANCE = CURRENTBALANCE + {amt} WHERE ACCOUNTNUMBER = '{accno}'";
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public SBAccount GetAccount(string accno)
        {
            cmd.CommandText = $"SELECT * FROM SBACCOUNT WHERE ACCOUNTNUMBER = '{accno}'";
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                SBAccount account = new SBAccount();
                account.AccountNumber = (string)reader["AccountNumber"];
                account.CustomerName = (string)reader["CustomerName"];
                account.CustomerAddress = (string)reader["CustomerAddress"];
                account.CurrentBalance = (decimal)reader["CurrentBalance"];
                con.Close();
                return account;
            }
            else
            {
                con.Close();
                throw new BankException("No such A/C #");
            }
        }
        public List<SBAccount> GetAllAccounts()
        {
            cmd.CommandText = "SELECT * FROM SBACCOUNT";
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<SBAccount> accounts = new List<SBAccount>();
            while (reader.Read())
            {
                SBAccount account = new SBAccount();
                account.AccountNumber = (string)reader["AccountNumber"];
                account.CustomerName = (string)reader["CustomerName"];
                account.CustomerAddress = (string)reader["CustomerAddress"];
                account.CurrentBalance = (decimal)reader["CurrentBalance"];
                accounts.Add(account);
            }
            con.Close();
            return accounts;
        }
        public List<SBTransaction> GetTransactions(string accno) {
            cmd.CommandText = $"SELECT * FROM SBTRANSACTION WHERE ACCOUNTNUMBER = '{accno}'";
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<SBTransaction> transactions = new List<SBTransaction>();
            while (reader.Read()) {
                SBTransaction transaction = new SBTransaction();
                transaction.TransactionId = (int)reader["TransactionId"];
                transaction.AccountNumber = (string)reader["AccountNumber"];
                transaction.TransactionDate = (DateTime)reader["TransactionDate"];
                transaction.Amount = (decimal)reader["Amount"];
                transaction.TransactionType = (string)reader["TransactionType"];
                transactions.Add(transaction);
            }
            con.Close();
            return transactions;
        }
        public void InsertAccount(SBAccount account) {
            cmd.CommandText = $"INSERT INTO SBACCOUNT VALUES('{account.AccountNumber}', '{account.CustomerName}', '{account.CustomerAddress}', {account.CurrentBalance})";
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public void WithdrawAmount(string accno, decimal amt) {
            SBAccount account = GetAccount(accno);
            if (account.CurrentBalance >= amt) {
                cmd.CommandText = $"INSERT INTO SBTRANSACTION VALUES('{accno}', '{DateTime.Now}', {amt}, 'W')";
                con.Open();
                cmd.ExecuteNonQuery();
                cmd.CommandText = $"UPDATE SBACCOUNT SET CURRENTBALANCE = CURRENTBALANCE - {amt} WHERE ACCOUNTNUMBER = '{accno}'";
                cmd.ExecuteNonQuery();
                con.Close();
            }
            else {
                throw new BankException("Cannot withdraw because of insufficient funds");
            }
        }
    }
}
