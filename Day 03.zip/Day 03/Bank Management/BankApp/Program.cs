﻿using BankLibrary;
using Microsoft.Identity.Client;

namespace BankApp
{
    internal class Program {
        static IBankRepository bankRepo = new ADOBankRepository();
        static void Main(string[] args) {
            while (true) {
                Console.WriteLine("---------------");
                Console.WriteLine("--- M E N U ---");
                Console.WriteLine("---------------");
                Console.WriteLine("1. Add Account");
                Console.WriteLine("2. View Account");
                Console.WriteLine("3. View All Accounts");
                Console.WriteLine("4. Deposit Amount");
                Console.WriteLine("5. Withdraw Amount");
                Console.WriteLine("6. View Transactions");
                Console.WriteLine("7. Exit");
                Console.Write("Enter your choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice) {
                    case 1: AddAccount(); break;
                    case 2: ViewAccount(); break;
                    case 3: ViewAllAccounts(); break;
                    case 4: Deposit(); break;
                    case 5: Withdraw(); break;
                    case 6: ViewTransactions(); break;
                    case 7: return;
                }
            }
        }
        private static void ViewTransactions() {
            Console.Write("Enter A/C # to view transactions: ");
            string accno = Console.ReadLine();
            List<SBTransaction> transactions = bankRepo.GetTransactions(accno);
            foreach (SBTransaction transaction in transactions) {
                Console.WriteLine($"Transaction Id: {transaction.TransactionId}, A/C #: {transaction.AccountNumber}, Date: {transaction.TransactionDate}, Amount: {transaction.Amount}, Type: {transaction.TransactionType}");
            }
        }
        private static void Withdraw() {
            Console.Write("Enter A/C # to withdraw: ");
            string accno = Console.ReadLine();
            Console.Write("Enter amount: ");
            decimal amt = Convert.ToDecimal(Console.ReadLine());
            try {
                bankRepo.WithdrawAmount(accno, amt);
                Console.WriteLine("Amount withdrawn");
            }
            catch (BankException ex) {
                Console.WriteLine(ex.Message);
            }
        }
        private static void Deposit() {
            Console.Write("Enter A/C # to deposit: ");
            string accno = Console.ReadLine();
            Console.Write("Enter amount: ");
            decimal amt = Convert.ToDecimal(Console.ReadLine());
            bankRepo.DepositAmount(accno, amt);
            Console.WriteLine("Amount deposited");
        }
        private static void ViewAllAccounts() {
            List<SBAccount> accounts = bankRepo.GetAllAccounts();
            Console.WriteLine("List of accounts...");
            foreach (SBAccount account in accounts) {
                Console.WriteLine($"A/C #: {account.AccountNumber}, Customer Name: {account.CustomerName}, Address: {account.CustomerAddress}, Balance: Rs.{account.CurrentBalance}/-");
            }
        }
        private static void ViewAccount() {
            Console.Write("Enter A/C # to view: ");
            string accno = Console.ReadLine();
            try {
                SBAccount account = bankRepo.GetAccount(accno);
                Console.WriteLine($"A/C #: {account.AccountNumber}, Customer Name: {account.CustomerName}, Address: {account.CustomerAddress}, Balance: Rs.{account.CurrentBalance}/-");
            }
            catch (BankException ex) {
                Console.WriteLine(ex.Message);
            }
        }
        private static void AddAccount() {
            SBAccount account = new SBAccount();
            Console.Write("Enter A/C #: ");
            account.AccountNumber = Console.ReadLine();
            Console.Write("Enter customer name: ");
            account.CustomerName = Console.ReadLine();
            Console.Write("Enter address: ");
            account.CustomerAddress = Console.ReadLine();
            account.CurrentBalance = 0;
            bankRepo.InsertAccount(account);
            Console.WriteLine("New account added");
        }
    }
}
