﻿using Microsoft.Data.SqlClient;

namespace ConnectDBDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; database=ZelisDBx; integrated security=true";
            try
            {
                con.Open();
                Console.WriteLine("Successfully connected");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return;
            }
            finally
            {
                con.Close();
            }
        }
    }
}
