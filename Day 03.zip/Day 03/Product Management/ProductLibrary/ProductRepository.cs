﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductLibrary
{
    public class ProductRepository : IProductRepository {
        List<Product> products = new List<Product>();
        public void DeleteProduct(int id) {
            Product prod2del = GetProductById(id);
            products.Remove(prod2del);
        }
        public List<Product> GetAllProducts() {
            return products;
        }
        public Product GetProductById(int id) {
            try {
                //Product product = products.Single(p => p.ProductId == id);
                Product product = (from p in products where p.ProductId == id select p).First();
                return product;
            }
            catch (Exception) {
                throw new ProductException("No such product id");
            }
        }
        public List<Product> GetProductsByCategory(string cat) {
            var prodsByCat = from p in products where p.Category == cat select p;
            return prodsByCat.ToList();
        }
        public void NewProduct(Product prod) {
            products.Add(prod);
        }
        public void UpdateProduct(int id, Product prod) {
            Product prod2edit = GetProductById(id);
            prod2edit.ProductName = prod.ProductName;
            prod2edit.Category = prod.Category;
            prod2edit.Price = prod.Price;
        }
    }
}
