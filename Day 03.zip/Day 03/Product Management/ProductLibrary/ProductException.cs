﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductLibrary
{
    public class ProductException : Exception
    {
        public ProductException(string errMsg) : base(errMsg) { }
    }
}
