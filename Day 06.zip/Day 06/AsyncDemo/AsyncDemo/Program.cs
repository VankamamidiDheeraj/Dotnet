﻿namespace AsyncDemo
{
    internal class Program
    {
        static void Wish()
        {
            Console.WriteLine("Good morning");
        }
        static async void Greet()
        {
            await Task.Run(() =>
            {
                Thread.Sleep(2000); // Simulate a delay
                Console.WriteLine("Hello, welcome to async programming!");
            });
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Main started");
            Wish();     // Synchronous call
            Greet();    // Asynchronous call
            Console.WriteLine("Main ended");
            Console.ReadLine(); // Prevent the console from closing immediately
        }
    }
}
