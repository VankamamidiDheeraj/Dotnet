using EFAirlinesLibrary.Models;
using EFAirlinesLibrary.Repos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Threading.Tasks;

namespace AirlinesRazorApp.Pages.Flights
{
    public class IndexModel : PageModel
    {
        public List<Flight> flights = new List<Flight>();
        IFlightRepository flightRepo = new EFFlightRepository();
        public async Task OnGet()
        {
            flights = await flightRepo.GetAllFlightsAsync();
        }
    }
}
