using EFAirlinesLibrary.Models;
using EFAirlinesLibrary.Repos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Threading.Tasks;

namespace AirlinesRazorApp.Pages.Flights
{
    public class CreateModel : PageModel
    {
        [BindProperty]
        public Flight Flight { get; set; }
        IFlightRepository flightRepo = new EFFlightRepository();

        public void OnGet()
        {
        }

        public async Task<IActionResult> OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            await flightRepo.InsertFlightAsync(Flight);
            return RedirectToPage("Index");
        }
    }
}
