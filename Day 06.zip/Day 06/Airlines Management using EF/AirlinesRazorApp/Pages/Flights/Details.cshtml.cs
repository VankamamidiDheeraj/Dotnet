using EFAirlinesLibrary.Models;
using EFAirlinesLibrary.Repos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Threading.Tasks;

namespace AirlinesRazorApp.Pages.Flights
{
    public class DetailsModel : PageModel
    {
        public Flight Flight { get; set; }
        IFlightRepository flightRepo = new EFFlightRepository();

        public async Task OnGet(string fno)
        {
            Flight = await flightRepo.GetFlightAsync(fno);
        }
    }
}
