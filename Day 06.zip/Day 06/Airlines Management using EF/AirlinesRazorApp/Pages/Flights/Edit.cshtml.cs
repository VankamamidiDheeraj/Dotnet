using EFAirlinesLibrary.Models;
using EFAirlinesLibrary.Repos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Threading.Tasks;

namespace AirlinesRazorApp.Pages.Flights
{
    public class EditModel : PageModel
    {
        [BindProperty]
        public Flight Flight { get; set; }
        IFlightRepository flightRepo = new EFFlightRepository();
        static string flightNo;

        public async Task OnGet(string fno)
        {
            flightNo = fno;
            Flight = await flightRepo.GetFlightAsync(flightNo);
        }
        public async Task<IActionResult> OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            await flightRepo.UpdateFlightAsync(flightNo, Flight);
            return RedirectToPage("Index");
        }
    }
}
