using EFAirlinesLibrary.Models;
using EFAirlinesLibrary.Repos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AirlinesRazorApp.Pages.FlightSchedules
{
    public class DetailsModel : PageModel
    {
        public FlightSchedule Schedule { get; set; }
        IFlightScheduleRepository fsRepo = new EFFlightScheduleRepository();
        public async Task OnGet(string fno, string fdate)
        {
            Schedule = await fsRepo.GetScheduleAsync(fno, Convert.ToDateTime(fdate));
        }
    }
}
