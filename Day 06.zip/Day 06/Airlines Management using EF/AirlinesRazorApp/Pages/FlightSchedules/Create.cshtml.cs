using EFAirlinesLibrary.Models;
using EFAirlinesLibrary.Repos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Threading.Tasks;

namespace AirlinesRazorApp.Pages.FlightSchedules
{
    public class CreateModel : PageModel
    {
        [BindProperty]
        public FlightSchedule Schedule { get; set; }
        IFlightScheduleRepository scheduleRepo = new EFFlightScheduleRepository();
        IFlightRepository flightRepo = new EFFlightRepository();
        public List<Flight> flights = new List<Flight>();
        public async Task OnGet()
        {
            flights = await flightRepo.GetAllFlightsAsync();
        }

        public async Task<IActionResult> OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            await scheduleRepo.InsertScheduleAsync(Schedule);
            return RedirectToPage("Index");
        }
    }
}
