using EFAirlinesLibrary.Models;
using EFAirlinesLibrary.Repos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AirlinesRazorApp.Pages.FlightSchedules
{
    public class ByFlightModel : PageModel
    {
        public List<FlightSchedule> schedules = new List<FlightSchedule>();
        IFlightScheduleRepository fsRepo = new EFFlightScheduleRepository();
        public string FlightNo { get; set; }
        public async Task OnGet(string fno)
        {
            FlightNo = fno;
            schedules = await fsRepo.GetSchedulesByFlightAsync(fno);
        }
    }
}
