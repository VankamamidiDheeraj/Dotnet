using EFAirlinesLibrary.Models;
using EFAirlinesLibrary.Repos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AirlinesRazorApp.Pages.FlightSchedules
{
    public class IndexModel : PageModel
    {
        public List<FlightSchedule> schedules = new List<FlightSchedule>();
        IFlightScheduleRepository fsRepo = new EFFlightScheduleRepository();
        public async Task OnGet()
        {
            schedules = await fsRepo.GetAllSchedulesAsync();
        }
    }
}
