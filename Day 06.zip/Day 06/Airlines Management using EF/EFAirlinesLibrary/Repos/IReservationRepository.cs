﻿using EFAirlinesLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFAirlinesLibrary.Repos
{
    public interface IReservationRepository
    {
        Task InsertReservationAsync(Reservation reservation);
        Task UpdateReservationAsync(string pnr, Reservation reservation);
        Task DeleteReservationAsync(string pnr);
        Task<List<Reservation>> GetAllReservationsAsync();
        Task<Reservation> GetReservationAsync(string pnr);
        Task<List<Reservation>> GetReservationsByScheduleAsync(string flightNo, DateTime flightDate);
        Task<List<Reservation>> GetReservationsByDateAsync(DateTime resDate);
    }
}
