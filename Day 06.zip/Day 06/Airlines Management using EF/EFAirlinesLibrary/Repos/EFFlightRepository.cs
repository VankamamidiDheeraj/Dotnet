﻿using EFAirlinesLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFAirlinesLibrary.Repos
{
    public class EFFlightRepository : IFlightRepository {
        ZelisAirlinesDBContext ctx = new ZelisAirlinesDBContext();
        public async Task DeleteFlightAsync(string flightNo) {
            Flight flight2del = await GetFlightAsync(flightNo);
            try {
                ctx.Flights.Remove(flight2del);
                await ctx.SaveChangesAsync();
            }
            catch (Exception ex) {
                throw new AirlinesException(ex.Message);
            }
        }
        public async Task<List<Flight>> GetAllFlightsAsync() {
            List<Flight> flights = await ctx.Flights.ToListAsync();
            return flights;
        }
        public async Task<Flight> GetFlightAsync(string flightNo) {
            try {
                Flight flight = await (from f in ctx.Flights where f.FlightNo == flightNo  select f).FirstAsync();
                return flight;
            }
            catch {
                throw new AirlinesException("Flight not found!");
            }
        }
        public async Task InsertFlightAsync(Flight flight) {
            try {
                await ctx.Flights.AddAsync(flight);
                await ctx.SaveChangesAsync();
            }
            catch (Exception ex) {
                throw new AirlinesException(ex.Message);
            }    
        }
        public async Task UpdateFlightAsync(string flightNo, Flight flight) {
            Flight flight2edit = await GetFlightAsync(flightNo);
            try {
                flight2edit.FromCity = flight.FromCity;
                flight2edit.ToCity = flight.ToCity;
                flight2edit.TotalSeats = flight.TotalSeats;
                await ctx.SaveChangesAsync();
            }
            catch (Exception ex) {
                throw new AirlinesException(ex.Message);
            }
        }
    }
}
