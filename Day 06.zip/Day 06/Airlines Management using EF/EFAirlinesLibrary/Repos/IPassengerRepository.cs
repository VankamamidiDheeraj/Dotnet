﻿using EFAirlinesLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFAirlinesLibrary.Repos
{
    public interface IPassengerRepository
    {
        Task InsertPassengerAsync(Passenger passenger);
        Task UpdatePassengerAsync(string pnr, int passNo, Passenger passenger);
        Task DeletePassengerAsync(string pnr, int passNo);
        Task<List<Passenger>> GetAllPassengersAsync();
        Task<Passenger> GetPassengerAsync(string pnr, int passNo);
        Task<List<Passenger>> GetPassengersByPNRAsync(string pnr);
    }
}
