﻿using EFAirlinesLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFAirlinesLibrary.Repos
{
    public class EFPassengerRepository : IPassengerRepository {
        ZelisAirlinesDBContext ctx = new ZelisAirlinesDBContext();
        public async Task DeletePassengerAsync(string pnr, int passNo) {
            Passenger pass2del = await GetPassengerAsync(pnr, passNo);
            try {
                ctx.Passengers.Remove(pass2del);
                await ctx.SaveChangesAsync();
            }
            catch (Exception ex) {
                throw new AirlinesException(ex.Message);
            }
        }
        public async Task<List<Passenger>> GetAllPassengersAsync() {
            List<Passenger> passengers = await ctx.Passengers.ToListAsync();   
            return passengers;
        }
        public async Task<Passenger> GetPassengerAsync(string pnr, int passNo) {
            try {
                Passenger passenger = await (from p in ctx.Passengers where p.PNR == pnr && p.PassengerNo == passNo select p).FirstAsync();
                return passenger;
            }
            catch {
                throw new AirlinesException("Passenger not found!");
            }
        }
        public async Task<List<Passenger>> GetPassengersByPNRAsync(string pnr) {
            List<Passenger> passengers = await (from p in ctx.Passengers where p.PNR == pnr select p).ToListAsync();
            if (passengers.Count == 0) {
                throw new AirlinesException("No passengers found for the given PNR!");
            }
            else {
               return passengers;
            }
        }
        public async Task InsertPassengerAsync(Passenger passenger) {
            try {
                await ctx.Passengers.AddAsync(passenger);
                await ctx.SaveChangesAsync();
            }
            catch (Exception ex) {
                throw new AirlinesException(ex.Message);
            }
        }
        public async Task UpdatePassengerAsync(string pnr, int passNo, Passenger passenger) {
            Passenger pass2edit = await GetPassengerAsync(pnr, passNo);
            try {
                pass2edit.PassengerName = passenger.PassengerName;
                pass2edit.Gender = passenger.Gender;
                pass2edit.Age = passenger.Age;
                await ctx.SaveChangesAsync();
            }
            catch (Exception ex) {
                throw new AirlinesException(ex.Message);
            }
        }
    }
}
