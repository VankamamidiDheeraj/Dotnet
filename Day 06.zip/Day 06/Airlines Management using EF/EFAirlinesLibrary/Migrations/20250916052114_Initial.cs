﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EFAirlinesLibrary.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Flight",
                columns: table => new
                {
                    FlightNo = table.Column<string>(type: "CHAR(6)", nullable: false),
                    FromCity = table.Column<string>(type: "VARCHAR(20)", nullable: false),
                    ToCity = table.Column<string>(type: "VARCHAR(20)", nullable: false),
                    TotalSeats = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Flight", x => x.FlightNo);
                });

            migrationBuilder.CreateTable(
                name: "FlightSchedule",
                columns: table => new
                {
                    FlightNo = table.Column<string>(type: "CHAR(6)", nullable: false),
                    FlightDate = table.Column<DateTime>(type: "DATETIME", nullable: false),
                    DepartTime = table.Column<DateTime>(type: "DATETIME", nullable: false),
                    ArriveTime = table.Column<DateTime>(type: "DATETIME", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FlightSchedule", x => new { x.FlightNo, x.FlightDate });
                    table.ForeignKey(
                        name: "FK_FlightSchedule_Flight_FlightNo",
                        column: x => x.FlightNo,
                        principalTable: "Flight",
                        principalColumn: "FlightNo",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Reservation",
                columns: table => new
                {
                    PNR = table.Column<string>(type: "CHAR(6)", nullable: false),
                    FlightNo = table.Column<string>(type: "CHAR(6)", nullable: false),
                    FlightDate = table.Column<DateTime>(type: "DATETIME", nullable: false),
                    ReservationDate = table.Column<DateTime>(type: "DATETIME", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Reservation", x => x.PNR);
                    table.ForeignKey(
                        name: "FK_Reservation_FlightSchedule_FlightNo_FlightDate",
                        columns: x => new { x.FlightNo, x.FlightDate },
                        principalTable: "FlightSchedule",
                        principalColumns: new[] { "FlightNo", "FlightDate" },
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Passenger",
                columns: table => new
                {
                    PNR = table.Column<string>(type: "CHAR(6)", nullable: false),
                    PassengerNo = table.Column<int>(type: "int", nullable: false),
                    PassengerName = table.Column<string>(type: "VARCHAR(30)", nullable: false),
                    Gender = table.Column<string>(type: "CHAR(1)", nullable: false),
                    Age = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Passenger", x => new { x.PNR, x.PassengerNo });
                    table.ForeignKey(
                        name: "FK_Passenger_Reservation_PNR",
                        column: x => x.PNR,
                        principalTable: "Reservation",
                        principalColumn: "PNR",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Reservation_FlightNo_FlightDate",
                table: "Reservation",
                columns: new[] { "FlightNo", "FlightDate" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Passenger");

            migrationBuilder.DropTable(
                name: "Reservation");

            migrationBuilder.DropTable(
                name: "FlightSchedule");

            migrationBuilder.DropTable(
                name: "Flight");
        }
    }
}
