﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace EFAirlinesLibrary.Models
{
    [Table("FlightSchedule")]
    [PrimaryKey("FlightNo", "FlightDate")]
    public class FlightSchedule
    {
        [Column(TypeName = "CHAR(6)")]
        [ForeignKey("Flight")]
        public string FlightNo { get; set; }
        [Column(TypeName = "DATETIME")]
        public DateTime FlightDate { get; set; }
        [Column(TypeName = "DATETIME")]
        public DateTime DepartTime { get; set; }
        [Column(TypeName = "DATETIME")]
        public DateTime ArriveTime { get; set; }

        public virtual Flight? Flight { get; set; }
        public virtual ICollection<Reservation> Reservations { get; set; } = new List<Reservation>();
    }
}
