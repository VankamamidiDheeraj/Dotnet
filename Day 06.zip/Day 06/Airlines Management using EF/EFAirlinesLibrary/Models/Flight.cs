﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFAirlinesLibrary.Models
{
    [Table("Flight")]
    public class Flight
    {
        [Key]
        [Column(TypeName = "CHAR(6)")]
        public string FlightNo { get; set; }
        [Column(TypeName = "VARCHAR(20)")]
        [Required]
        public string FromCity { get; set; }
        [Column(TypeName = "VARCHAR(20)")]
        [Required]
        public string ToCity { get; set; }
        public int TotalSeats { get; set; }

        public virtual ICollection<FlightSchedule> FlightSchedules { get; set; } = new List<FlightSchedule>();
    }
}
