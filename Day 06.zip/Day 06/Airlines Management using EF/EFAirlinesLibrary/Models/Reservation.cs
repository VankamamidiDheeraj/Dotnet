﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFAirlinesLibrary.Models
{
    [Table("Reservation")]
    public class Reservation
    {
        [Key]
        [Column(TypeName = "CHAR(6)")]
        public string PNR { get; set; }
        [Column(TypeName = "CHAR(6)")]
        public string FlightNo { get; set; }
        [Column(TypeName = "DATETIME")]
        public DateTime FlightDate { get; set; }
        [Column(TypeName = "DATETIME")]
        public DateTime ReservationDate { get; set; }

        [ForeignKey("FlightNo, FlightDate")]
        public virtual FlightSchedule FlightSchedule { get; set; }
        public virtual ICollection<Passenger> Passengers { get; set; } = new List<Passenger>();
    }
}
