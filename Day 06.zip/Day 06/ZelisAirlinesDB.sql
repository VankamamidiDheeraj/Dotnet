﻿CREATE DATABASE ZelisAirlinesDB

USE ZelisAirlinesDB

CREATE TABLE Flight (
FlightNo CHAR(6) PRIMARY KEY,
FromCity VARCHAR(20) NOT NULL,
ToCity VARCHAR(20) NOT NULL,
TotalSeats INT)

CREATE TABLE FlightSchedule (
FlightNo CHAR(6) REFERENCES Flight,
FlightDate DATETIME,
DepartTime DATETIME,
ArriveTime DATETIME,
PRIMARY KEY (FlightNo, FlightDate))

CREATE TABLE Reservation (
PNR CHAR(6) PRIMARY KEY,
FlightNo CHAR(6),
FlightDate DATETIME,
ReserveDate DATETIME,
FOREIGN KEY(FlightNo, FlightDate) REFERENCES FlightSchedule)

CREATE TABLE Passenger (
PNR CHAR(6) REFERENCES Reservation,
PassengerNo INT,
PassengerName VARCHAR(30) NOT NULL,
Gender CHAR(1) CHECK (Gender IN ('M', 'F', 'O')),
Age INT,
PRIMARY KEY(PNR, PassengerNo))


