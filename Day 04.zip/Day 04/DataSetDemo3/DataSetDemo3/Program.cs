﻿using System.Data;
using Microsoft.Data.SqlClient;
namespace DataSetDemo3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; database=ZelisBankDB; integrated security=true";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = cmd;
            SqlCommandBuilder builder = new SqlCommandBuilder();
            builder.DataAdapter = adapter;
            DataSet ds = new DataSet("Bank");
            cmd.CommandText = "SELECT * FROM SBACCOUNT";
            adapter.Fill(ds, "SBAccount");
            DataTable dt = ds.Tables["SBAccount"];
            Console.Write("Enter A/C #: ");
            string accno = Console.ReadLine();
            Console.Write("Enter customer name: ");
            string cname = Console.ReadLine();
            Console.Write("Enter address: ");
            string caddr = Console.ReadLine();
            decimal bal = 0;
            DataRow row = dt.NewRow();
            row["AccountNumber"] = accno;
            row["CustomerName"] = cname;
            row["CustomerAddress"] = caddr;
            row["CurrentBalance"] = bal;
            dt.Rows.Add(row);
            adapter.Update(ds, "SBAccount");
            Console.WriteLine("New account added");
        }
    }
}
