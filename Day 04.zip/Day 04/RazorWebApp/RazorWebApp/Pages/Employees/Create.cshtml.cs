using EmployeeLibrary;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorWebApp.Pages.Employees
{
    public class CreateModel : PageModel
    {
        [BindProperty]
        public Employee Employee { get; set; }
        IEmployeeRepository empRepo = new ADOEmployeeRepository();

        public void OnGet()
        {
        }

        public IActionResult OnPost() {
            empRepo.InsertEmployee(Employee);
            return RedirectToPage("/Employees/Index");
        }
    }
}
