using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using EmployeeLibrary;

namespace RazorWebApp.Pages.Employees
{
    public class IndexModel : PageModel
    {
        public List<Employee> employees = new List<Employee>();
        IEmployeeRepository empRepo = new ADOEmployeeRepository();
        public void OnGet()
        {
            employees = empRepo.GetAllEmployees();
        }
    }
}
