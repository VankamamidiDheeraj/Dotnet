using EmployeeLibrary;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorWebApp.Pages.Employees
{
    public class EditModel : PageModel
    {
        [BindProperty]
        public Employee Employee { get; set; }
        IEmployeeRepository empRepo = new ADOEmployeeRepository();
        static int empid;

        public void OnGet(int eid)
        {
            empid = eid;
            Employee = empRepo.GetEmployee(eid);
        }
        public IActionResult OnPost()
        {
            empRepo.UpdateEmployee(empid, Employee);
            return RedirectToPage("/Employees/Index");
        }
    }
}
