using EmployeeLibrary;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorWebApp.Pages.Employees
{
    public class DetailsModel : PageModel
    {
        public Employee Employee { get; set; }
        IEmployeeRepository empRepo = new ADOEmployeeRepository();

        public void OnGet(int eid)
        {
            Employee = empRepo.GetEmployee(eid);
        }
    }
}
