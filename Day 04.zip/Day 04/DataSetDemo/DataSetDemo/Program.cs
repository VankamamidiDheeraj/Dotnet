﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace DataSetDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; database=ZelisBankDB; integrated security=true";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = cmd;
            DataSet ds = new DataSet("Bank");
            cmd.CommandText = "SELECT * FROM SBACCOUNT";
            adapter.Fill(ds, "SBAccount");
            cmd.CommandText = "SELECT * FROM SBTRANSACTION";
            adapter.Fill(ds, "SBTransaction");
            for (int t = 0; t < ds.Tables.Count; t++) {
                DataTable dt = ds.Tables[t];
                Console.WriteLine($"Records in table {dt.TableName}...");
                for (int r = 0; r < dt.Rows.Count; r++) {
                    DataRow row = dt.Rows[r];
                    for (int c = 0; c < dt.Columns.Count; c++) {
                        Console.Write(row[c]);
                        Console.Write("\t");
                    }
                    Console.WriteLine();
                }
            }
            DataColumn pkey = ds.Tables["SBAccount"].Columns["AccountNumber"];
            DataColumn fkey = ds.Tables["SBTransaction"].Columns["AccountNumber"];
            DataRelation relation = new DataRelation("bank_rel", pkey, fkey);
            ds.Relations.Add(relation);
            ds.WriteXml(@"F:\Zelis-DotNet\Day 04\Bank.xml");
            ds.WriteXmlSchema(@"F:\Zelis-DotNet\Day 04\Bank.xsd");
            //ds.WriteXml(@"F:\Zelis-DotNet\Day 03\SBAccount.xml");
            //ds.WriteXmlSchema(@"F:\Zelis-DotNet\Day 03\SBAccount.xsd");
        }
    }
}
