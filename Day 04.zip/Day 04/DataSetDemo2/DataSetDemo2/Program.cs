﻿using System.Data;

namespace DataSetDemo2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DataSet ds = new DataSet();
            ds.ReadXmlSchema(@"F:\Zelis-DotNet\Day 04\Bank.xsd");
            ds.ReadXml(@"F:\Zelis-DotNet\Day 04\Bank.xml");
            for (int t = 0; t < ds.Tables.Count; t++)
            {
                DataTable dt = ds.Tables[t];
                Console.WriteLine($"Records in table {dt.TableName}...");
                for (int r = 0; r < dt.Rows.Count; r++)
                {
                    DataRow row = dt.Rows[r];
                    for (int c = 0; c < dt.Columns.Count; c++)
                    {
                        Console.Write(row[c]);
                        Console.Write("\t");
                    }
                    Console.WriteLine();
                }
            }
        }
    }
}
