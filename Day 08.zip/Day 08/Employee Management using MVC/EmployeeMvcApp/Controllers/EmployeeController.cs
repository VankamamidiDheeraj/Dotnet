﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EFEmployeeLibray.Models;
using EFEmployeeLibray.Repos;
using EmployeeMvcApp.Filters;

namespace EmployeeMvcApp.Controllers {
    //[TypeFilter(typeof(LogActionFilterAttribute))]
    //[LogActionFilter]
    [TypeFilter(typeof(CustomExceptionFilter))]
    public class EmployeeController : Controller {
        private readonly ILogger<EmployeeController> _logger;
        IEmployeeRepository empRepo;
        public EmployeeController(IEmployeeRepository repository, ILogger<EmployeeController> logger)
        {
            empRepo = repository;
            _logger = logger;
        }
        //[LogActionFilter]
        public ActionResult Index() {
            _logger.LogInformation("Fetching all employees");
            List<Employee> employees = empRepo.GetAllEmployees();
            return View(employees);
        }
        public ActionResult Details(int id) {
            _logger.LogInformation($"Fetching details for employee ID: {id}");
            Employee employee = empRepo.GetEmployee(id);
            return View(employee);
        }
        public ActionResult Create() {
            Employee emp = new Employee();
            return View(emp);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Employee emp) {
            empRepo.InsertEmployee(emp);
            return RedirectToAction(nameof(Index));
        }
        public ActionResult Edit(int id) {
            Employee employee = empRepo.GetEmployee(id);
            return View(employee);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Employee emp) {
            empRepo.UpdateEmployee(id, emp);
            return RedirectToAction(nameof(Index));
        }
        public ActionResult Delete(int id) {
            Employee employee = empRepo.GetEmployee(id);
            return View(employee);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection) {
            empRepo.DeleteEmployee(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
