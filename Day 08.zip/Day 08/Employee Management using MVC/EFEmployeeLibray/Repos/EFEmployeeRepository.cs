﻿using EFEmployeeLibray.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFEmployeeLibray.Repos
{
    public class EFEmployeeRepository : IEmployeeRepository {
        ZelisDBContext ctx = new ZelisDBContext();
        public void DeleteEmployee(int eid) {
            Employee emp2del = GetEmployee(eid);
            try {
                ctx.Employees.Remove(emp2del);
                ctx.SaveChanges();
            }
            catch (Exception ex) {
                throw new EmpException(ex.Message);
            }
        }
        public List<Employee> GetAllEmployees() {
            List<Employee> employees = ctx.Employees.ToList();
            return employees;
        }
        public Employee GetEmployee(int eid) {
            try {
                Employee emp = (from e in ctx.Employees where e.EmpId == eid select e).First();
                return emp;
            }
            catch {
                throw new EmpException("No such emp id");
            }
        }
        public void InsertEmployee(Employee employee) {
            try {
                ctx.Employees.Add(employee);
                ctx.SaveChanges();
            }
            catch (Exception ex) {
                throw new EmpException(ex.Message);
            }
        }
        public void UpdateEmployee(int eid, Employee employee) {
            Employee emp2edit = GetEmployee(eid);
            emp2edit.EmpName = employee.EmpName;
            emp2edit.Salary = employee.Salary;
            try {
                ctx.SaveChanges();
            }
            catch (Exception ex) {
                throw new EmpException(ex.Message);
            }
        }
    }
}
