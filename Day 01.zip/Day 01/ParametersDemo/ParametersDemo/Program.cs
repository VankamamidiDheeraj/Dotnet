﻿namespace ParametersDemo
{
    internal class Program
    {
        static int Add(int x, int y) {  // IN Parameters (pass by value)
            return x + y;
        }
        static void Increment(int x) {
            x++;
        }
        static void SumnProduct(int x, int y, out int sum, out int product) { // OUT Params
            sum = x + y;
            product = x * y;
        }
        static void Swap(ref int x, ref int y) {  // REF Params(pass by reference)
            int t = x;
            x = y; 
            y = t;
        }
        static void PrintNames(params string[] names) { // Parameter Array
            foreach (string name in names)
                Console.WriteLine(name);
        }
        static void SendEmail(string fromAddr, string toAddr, string ccAddr="", string bccAddr = null) {    // Optional Parameters
            // some code to send email
        }
        static void Main(string[] args) {
            int a, b;
            a = 4;  b = 5;
            int res;
            res = Add(a, b);    // Arguments
            Increment(a);
            Console.WriteLine($"a={a}");
            int res1, res2;
            SumnProduct(a, b, out res1, out res2);
            Console.WriteLine($"Sum={res1}, Product={res2}");
            Swap(ref a, ref b);
            Console.WriteLine($"a={a}, b={b}");
            PrintNames("Apple", "Banana", "Grape", "Orange");
            PrintNames("Raja", "Devi", "Usha");
            res = Add(y: b, x: a);  // Named Arguments
            SendEmail("abc@zelis.com", "xyz@zelis.com");
            SendEmail("abc@zelis.com", "xyz@zelis.com", "bcd@zelis.com");
            SendEmail("abc@zelis.com", "xyz@zelis.com", "bcd@zelis.com", "cde@zelis.com");
            SendEmail("abc@zelis.com", "xyz@zelis.com", bccAddr: "cde@zelis.com");
        }
    }
}
