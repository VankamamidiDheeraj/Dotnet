﻿namespace JaggedArrayDemo
{
    internal class Program
    {
        static void Main(string[] args) {
            string[][] familyMembers;
            Console.Write("How many families? ");
            int familyCount = Convert.ToInt32(Console.ReadLine());
            familyMembers = new string[familyCount][];
            for (int f = 0; f < familyCount; f++) {
                Console.Write($"How many members in family #{f+1}? ");
                int memberCount = Convert.ToInt32(Console.ReadLine());
                familyMembers[f] = new string[memberCount];
                for (int m = 0; m < memberCount; m++) {
                    Console.Write("Enter member name: ");
                    familyMembers[f][m] = Console.ReadLine();
                }
            }
            Console.WriteLine("Census details...");
            for (int f = 0; f < familyMembers.Length; f++) {
                Console.WriteLine($"Members in family #{f+1}...");
                for (int m = 0; m < familyMembers[f].Length; m++) {
                    Console.Write(familyMembers[f][m]);
                    Console.Write("\t");
                }
                Console.WriteLine();
            }
        }
    }
}
