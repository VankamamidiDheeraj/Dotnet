﻿using System.Runtime.ConstrainedExecution;

namespace ClassDemo
{
    class Person {
        string name;    // Field
        public string Name {    // Property
            get { return name; }
            set { name = value; }
        }
        private DateTime doBirth;
        public DateTime DoBirth {
            get { return doBirth; }
            set { doBirth = value; }
        }
        public byte Age {   // Read-only Property
            get { return (byte)(DateTime.Now.Year - doBirth.Year); }
        }
        string password;
        public string Password {    // Write-only Property
            set { password = value; }
        }
        public void AcceptDetails() {   // Method
            Console.Write("Enter name: ");
            name = Console.ReadLine();
            Console.Write("Enter date of birth: ");
            doBirth = Convert.ToDateTime(Console.ReadLine());
            Console.Write("Enter password: ");
            password = Console.ReadLine();
        }
        public void DisplayDetails() {
            Console.WriteLine($"Name: {name}, DoB: {doBirth}, Age: {Age}");
        }
        public Person() {   // Default Constructor
            name = "";
            doBirth = Convert.ToDateTime("01/01/2000");
            password = "";
        }
        public Person(string name, string dob, string pwd) { // Parameterized Constructor
            this.name = name;
            doBirth = Convert.ToDateTime(dob);
            password = pwd;
        }
    }
    class Employee : Person {   // Inheritance
        private int empId;
        public int EmpId {
            get { return empId; }
            set { empId = value; }
        }
        private decimal salary;
        public decimal Salary {
            get { return salary; }
            set { salary = value; }
        }
        public Employee() {
            empId = 0;
            salary = 0;
        }
        public Employee(string name, string dob, string pwd, int eid, decimal sal) : base(name, dob, pwd) {
            empId = eid;
            salary = sal;
        }
        public void AcceptDetails()  {
            base.AcceptDetails();
            Console.Write("Enter emp id: ");
            empId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter salary: ");
            salary = Convert.ToDecimal(Console.ReadLine());
        }
        public void DisplayDetails() {
            base.DisplayDetails();
            Console.WriteLine($"Emp Id: {empId}, Salary: {salary}");
        }
    }
    class Student : Person { }  // Single Inheritance
    class Manager : Employee { }    // Multilevel Inheritance
    internal class Program {
        static void Main(string[] args) {
            Employee emp = new Employee();
            emp.AcceptDetails();
            emp.DisplayDetails();
            Employee emp2 = new Employee("Usha", "02/10/2003", "abc@#123", 102, 45000);
            emp2.DisplayDetails();
            Person per;     // Declare an object
            per = new Person(); // Instantiate the object
            per.AcceptDetails();
            per.DisplayDetails();
            Person per2 = new Person("Devi", "05/11/2003", "secret");
            per2.DisplayDetails();
        }
    }
}
