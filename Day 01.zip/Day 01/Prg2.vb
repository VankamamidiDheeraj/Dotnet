Module M1
  Sub Main()
    System.Console.WriteLine("Welcome to DotNet")
  End Sub
End Module
