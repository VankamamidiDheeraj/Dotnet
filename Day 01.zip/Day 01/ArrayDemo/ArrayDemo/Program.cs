﻿namespace ArrayDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numbers;  // Declare the array
            //numbers = new int[10];  // Instantiate the array
            //OR
            Console.Write("How many numbers? ");
            int size = Convert.ToInt32(Console.ReadLine());
            numbers = new int[size];
            for (int i = 0; i < numbers.Length; i++)
            {
                Console.Write("Enter a number: ");
                numbers[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("Numbers in the array...");
            for (int i = 0; i < size; i++)
            {
                Console.WriteLine(numbers[i]);
            }
            //OR
            foreach (int num in numbers)
            {
                Console.WriteLine(num);
            }
            Console.Write("Enter a number to search: ");
            int number = Convert.ToInt32(Console.ReadLine());
            int pos = Array.IndexOf(numbers, number);
            if (pos >= 0)
                Console.WriteLine($"Number found in position {pos}");
            else
                Console.WriteLine("Number not found");
            Array.Sort(numbers);
            Console.WriteLine("Numbers in ascending order...");
            foreach (int num in numbers)
            {
                Console.WriteLine(num);
            }
            Array.Reverse(numbers);
            Console.WriteLine("Numbers in descending order...");
            foreach (int num in numbers)
            {
                Console.WriteLine(num);
            }
        }
    }
}
