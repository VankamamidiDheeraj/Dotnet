﻿using System.Linq.Expressions;

namespace IODemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int empId;
            Console.Write("Enter emp id: ");
            //empId = Convert.ToInt32(Console.ReadLine());
            //OR
            empId = int.Parse(Console.ReadLine());
            Console.Write("Enter name: ");
            string empName = Console.ReadLine();
            Console.Write("Enter salary: ");
            decimal sal = Convert.ToDecimal(Console.ReadLine());
            //Console.WriteLine("Emp Id: {0}, Name: {1}, Salary: {2}", empId, empName, sal);
            //OR
            Console.WriteLine($"Emp Id: {empId}, Name: {empName}, Salary: {sal}");
        }
    }
}
