﻿namespace DataTypesDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            System.Byte a;
            byte b;
            System.Int32 c;
            int d;
            object x;
            x = 5;
            x = "Apple";
            //d = "Banana";
        }
    }
}
