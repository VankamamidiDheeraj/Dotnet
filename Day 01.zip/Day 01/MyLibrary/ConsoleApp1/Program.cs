﻿using MyLibrary;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            emp.AcceptDetails();
            emp.DisplayDetails();
        }
    }
}
