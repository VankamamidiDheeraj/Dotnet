﻿namespace MyLibrary
{
    public class Person
    {
        string name;    // Field
        public string Name
        {    // Property
            get { return name; }
            set { name = value; }
        }
        private DateTime doBirth;
        public DateTime DoBirth
        {
            get { return doBirth; }
            set { doBirth = value; }
        }
        public byte Age
        {   // Read-only Property
            get { return (byte)(DateTime.Now.Year - doBirth.Year); }
        }
        string password;
        public string Password
        {    // Write-only Property
            set { password = value; }
        }
        public void AcceptDetails()
        {   // Method
            Console.Write("Enter name: ");
            name = Console.ReadLine();
            Console.Write("Enter date of birth: ");
            doBirth = Convert.ToDateTime(Console.ReadLine());
            Console.Write("Enter password: ");
            password = Console.ReadLine();
        }
        public void DisplayDetails()
        {
            Console.WriteLine($"Name: {name}, DoB: {doBirth}, Age: {Age}");
        }
        public Person()
        {   // Default Constructor
            name = "";
            doBirth = Convert.ToDateTime("01/01/2000");
            password = "";
        }
        public Person(string name, string dob, string pwd)
        { // Parameterized Constructor
            this.name = name;
            doBirth = Convert.ToDateTime(dob);
            password = pwd;
        }
    }
}
