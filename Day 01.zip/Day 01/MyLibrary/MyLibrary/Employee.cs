﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary
{
    public class Employee : Person
    {
        private int empId;
        public int EmpId
        {
            get { return empId; }
            set { empId = value; }
        }
        private decimal salary;
        public decimal Salary
        {
            get { return salary; }
            set { salary = value; }
        }
        public Employee()
        {
            empId = 0;
            salary = 0;
        }
        public Employee(string name, string dob, string pwd, int eid, decimal sal) : base(name, dob, pwd)
        {
            empId = eid;
            salary = sal;
        }
        public void AcceptDetails()
        {
            base.AcceptDetails();
            Console.Write("Enter emp id: ");
            empId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter salary: ");
            salary = Convert.ToDecimal(Console.ReadLine());
        }
        public void DisplayDetails()
        {
            base.DisplayDetails();
            Console.WriteLine($"Emp Id: {empId}, Salary: {salary}");
        }
    }
}
