﻿using System.Data.Common;

namespace AbstractDemo
{
    abstract class Sample   // Abstract Class
    {
        public abstract string Message { get; set; }    // Abstract Property
        public abstract void PrintMessage();    // Abstract Method
    }
    class Example : Sample {
        string message;
        public override string Message {
            get { return message; }
            set { message = value; }
        }
        public override void PrintMessage() {
            Console.WriteLine(message);
        }
    }
    abstract class Shape {
        public abstract void Draw();
        public abstract double Area { get; }
    }
    class Circle : Shape {
        double radius;
        public override double Area {
            get { return Math.PI * radius * radius; }
        }
        public override void Draw() {
            Console.WriteLine("Drawing a circle");
        }
        public Circle(double rad) {
            radius = rad;
        }
    }
    class Rectangle : Shape {
        double length, breadth;
        public override double Area {
            get { return length * breadth; }
        }
        public override void Draw() {
            Console.WriteLine("Drawing a rectangle");
        }
        public Rectangle(double len, double bre) {
            length = len; breadth = bre;
        }
    }
    internal class Program {
        static void Main(string[] args) {
            Shape shape;
            shape = new Rectangle(6.2, 4.3);
            shape.Draw();
            Console.WriteLine($"Area of the rectangle is {shape.Area}");
            shape = new Circle(8.4);
            shape.Draw();
            Console.WriteLine($"Area of the circle is {shape.Area}");
            Sample obj;
            //obj = new Sample();   // Error
            obj = new Example();
            obj.Message = "Hello";
            obj.PrintMessage();
        }
    }
}
