﻿namespace MatrixDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[,] matrix = new int[4, 3];  // 2D Array
            int[,,] cube = new int[3, 4, 2];    // 3D Array
            for (int r = 0; r < 4; r++)
            {
                for (int c = 0; c < 3; c++)
                {
                    Console.Write("Enter a number: ");
                    matrix[r, c] = Convert.ToInt32(Console.ReadLine());
                }
            }
            Console.WriteLine("The matrix is...");
            for (int r = 0; r < 4; r++)
            {
                for (int c = 0; c < 3; c++)
                {
                    Console.Write(matrix[r, c]);
                    Console.Write("\t");
                }
                Console.WriteLine();
            }
        }
    }
}
